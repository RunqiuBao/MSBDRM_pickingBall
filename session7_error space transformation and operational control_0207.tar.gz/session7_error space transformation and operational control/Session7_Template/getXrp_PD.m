function [tau] = getXrp_PD(u)



end