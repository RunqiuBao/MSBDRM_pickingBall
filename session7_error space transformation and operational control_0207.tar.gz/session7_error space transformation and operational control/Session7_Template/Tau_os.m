function [ tau ] = Tau_os( u )
%TAU Summary of this function goes here
%   Detailed explanation goes here
% Times are defined in TrajGen.m file
global t0 t1 t2 t3 t4 t5 t6

t=u(1);

x1d=u(2);
x2d=u(3);
x3d=u(4);
x4d=deg2rad(u(5));
x5d=deg2rad(u(6));
x6d=deg2rad(u(7));

x1dp=u(8);
x2dp=u(9);
x3dp=u(10);
x4dp=deg2rad(u(11));
x5dp=deg2rad(u(12));
x6dp=deg2rad(u(13));

Kd=diag([u(14);u(15);u(16)]);
Kp=diag([u(17);u(18);u(19)]);

q1=u(20);
q2=u(21);
q3=u(22);

q1p=u(23);
q2p=u(24);
q3p=u(25);

Q=[q1;q2;q3];
Qp=[q1p;q2p;q3p];

Xd=[x1d;x2d;x3d;x4d;x5d;x6d];
Xdp=[x1dp;x2dp;x3dp;x4dp;x5dp;x6dp];

% %Joint Errors
% 
% 
% %Robot Parameters
% 
//m1=u(20);
m2=u(21);
m3=u(22);
g=u(23);

L1=u(24);
L2=u(25);
L4=u(26);
L6=u(27);
L7=u(28);
L9=u(29);
L3=u(30);
L5=u(31);
L8=u(32);
L10=u(33);
L11=u(34);

q1i=deg2rad(u(35));
q2i=deg2rad(u(36));
q3i=deg2rad(u(37));
q1di=deg2rad(u(44));
q2di=deg2rad(u(45));
q3di=deg2rad(u(46));
Qi=[q1i;q2i;q3i];
Qdi=[q1di;q2di;q3di];

Kis=diag([u(38);u(39);u(40)]);
Ki=diag([0;0;0]);

gx=u(41);
gy=u(42);
gz=u(43);//


Yr =[q1pp, q1pp/2 + (q1pp*cos(2*q2))/2 - q1p*q2p*sin(2*q2), - q1pp*sin(2*q2) - 2*q1p*q2p*cos(2*q2), sin(q2)*q2p^2 - q2pp*cos(q2), q1pp/2 - (q1pp*cos(2*q2))/2 + q1p*q2p*sin(2*q2), cos(q2)*q2p^2 + q2pp*sin(q2),    0, q1pp/2 + (q1pp*cos(2*q2 - 2*q3))/2 - q1p*q2p*sin(2*q2 - 2*q3) + q1p*q3p*sin(2*q2 - 2*q3), q1pp*sin(2*q2 - 2*q3) + 2*q1p*q2p*cos(2*q2 - 2*q3) - 2*q1p*q3p*cos(2*q2 - 2*q3), - sin(q2 - q3)*q2p^2 + 2*sin(q2 - q3)*q2p*q3p - sin(q2 - q3)*q3p^2 + q2pp*cos(q2 - q3) - q3pp*cos(q2 - q3), q1pp/2 - (q1pp*cos(2*q2 - 2*q3))/2 + q1p*q2p*sin(2*q2 - 2*q3) - q1p*q3p*sin(2*q2 - 2*q3), cos(q2 - q3)*q2p^2 - 2*cos(q2 - q3)*q2p*q3p + cos(q2 - q3)*q3p^2 + q2pp*sin(q2 - q3) - q3pp*sin(q2 - q3),           0, q1pp, q1pp/2 - (q1pp*cos(2*q2))/2 + q1p*q2p*sin(2*q2), q1pp/2 - (q1pp*cos(2*q2))/2 + q1p*q2p*sin(2*q2), q1pp, q1pp/2 - (q1pp*cos(2*q2 - 2*q3))/2 + q1p*q2p*sin(2*q2 - 2*q3) - q1p*q3p*sin(2*q2 - 2*q3), q1pp, sin(q2)*q2p^2 - q2pp*cos(q2), sin(q2)*q2p^2 - q2pp*cos(q2), q1pp*cos(q3) - q1pp*cos(2*q2 - q3) - q1p*q3p*sin(q3) + 2*q1p*q2p*sin(2*q2 - q3) - q1p*q3p*sin(2*q2 - q3), sin(q2)*q2p^2 - q2pp*cos(q2), sin(q2 - q3)*q2p^2 - 2*sin(q2 - q3)*q2p*q3p + sin(q2 - q3)*q3p^2 - q2pp*cos(q2 - q3) + q3pp*cos(q2 - q3), 2*q1pp, sin(q2 - q3)*q2p^2 - 2*sin(q2 - q3)*q2p*q3p + sin(q2 - q3)*q3p^2 - q2pp*cos(q2 - q3) + q3pp*cos(q2 - q3),         0,         0,               0;
    0,                             (q1p^2*sin(2*q2))/2,                        q1p^2*cos(2*q2),                -q1pp*cos(q2),                            -(q1p^2*sin(2*q2))/2,                 q1pp*sin(q2), q2pp,                                                               (q1p^2*sin(2*q2 - 2*q3))/2,                                                         -q1p^2*cos(2*q2 - 2*q3),                                                                                          q1pp*cos(q2 - q3),                                                              -(q1p^2*sin(2*q2 - 2*q3))/2,                                                                                        q1pp*sin(q2 - q3), q2pp - q3pp,    0,                      q2pp - (q1p^2*sin(2*q2))/2,                      q2pp - (q1p^2*sin(2*q2))/2,    0,                                                 q2pp - q3pp - (q1p^2*sin(2*q2 - 2*q3))/2,    0,                -q1pp*cos(q2),                -q1pp*cos(q2),               - sin(2*q2 - q3)*q1p^2 + sin(q3)*q3p^2 - 2*q2p*sin(q3)*q3p + 2*q2pp*cos(q3) - q3pp*cos(q3),                -q1pp*cos(q2),                                                                                       -q1pp*cos(q2 - q3),      0,                                                                                       -q1pp*cos(q2 - q3), g*sin(q2), g*sin(q2),  g*sin(q2 - q3);
    0,                                               0,                                      0,                            0,                                               0,                            0,    0,                                                              -(q1p^2*sin(2*q2 - 2*q3))/2,                                                          q1p^2*cos(2*q2 - 2*q3),                                                                                         -q1pp*cos(q2 - q3),                                                               (q1p^2*sin(2*q2 - 2*q3))/2,                                                                                       -q1pp*sin(q2 - q3), q3pp - q2pp,    0,                                               0,                                               0,    0,                                                 (sin(2*q2 - 2*q3)*q1p^2)/2 - q2pp + q3pp,    0,                            0,                            0,                              (q1p^2*sin(q3))/2 + q2p^2*sin(q3) + (q1p^2*sin(2*q2 - q3))/2 - q2pp*cos(q3),                            0,                                                                                        q1pp*cos(q2 - q3),      0,                                                                                        q1pp*cos(q2 - q3),         0,         0, -g*sin(q2 - q3)];

Theta=[I133;
       I211;
       I212;
       I213;
       I222;
       I223;
       I233;
       I311;
       I312;
       I313;
       I322;
       I323;
       I333;
       m2*L7^2;
       m2*L8^2;
       m3*L3^2;
       m3*L9^2;
       m3*L10^2;
       m3*L11^2;
       m2*L7*L8;
       m3*L3*L9;
       m3*L3*L10;
       m3*L3*L11;
       m3*L9*L10;
       m3*L9*L11;
       m3*L10*L11;
       m2*L8;
       m3*L3;
       m3*L10];
 

%error function
Eq=Qd-Q;
Eqp=Qdp-Qp;
Eqi=Qdi-Qi;




%Define controllers PD, PD+G, PID
%tauc=Kp*Q-Kd*Qp;%PD 
%tauc=Kp*Eq+Kd*Eqp+G;%PD+G
tauc=Kp*Eq+Kd*Eqp+Ki*Eqi+G;%PID+G


end

