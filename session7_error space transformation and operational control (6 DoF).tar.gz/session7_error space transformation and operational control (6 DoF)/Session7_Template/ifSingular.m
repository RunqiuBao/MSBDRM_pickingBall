function [isSingular] = ifSingular(u)
q1=rad2deg(u(1));
q2=rad2deg(u(2));
q3=rad2deg(u(3));
L1=u(30);
L2=u(31);
L4=u(32);
L6=u(33);
L7=u(34);
L9=u(35);
L3=u(36);
L5=u(37);
L8=u(38);
L10=u(39);
L11=u(40);

%singularity measure
%robot jacobian
Jef =[L11*cos(q1) + L3*sin(q1)*sin(q2),                                                                     -L3*cos(q1)*cos(q2),                                                                       0;
      L11*sin(q1) - L3*cos(q1)*sin(q2),                                                                     -L3*cos(q2)*sin(q1),                                                                       0;
                                     0, cos(q1)*(L11*sin(q1) - L3*cos(q1)*sin(q2)) - sin(q1)*(L11*cos(q1) + L3*sin(q1)*sin(q2)), cos(q1)*(L7*sin(q1) - L11*sin(q1)) - sin(q1)*(L7*cos(q1) - L11*cos(q1));
                                     0,                                                                                 sin(q1),                                                                -sin(q1);
                                     0,                                                                                -cos(q1),                                                                 cos(q1);
                                     1,                                                                                       0,                                                                       0];
isSingular=0;
w=sqrt(det(Jef(1:3,:)'*Jef(1:3,:)));     
reference2=det(Jef(1:3,:)'*Jef(1:3,:));
if w<=0.01
    isSingular=1;
end

end

