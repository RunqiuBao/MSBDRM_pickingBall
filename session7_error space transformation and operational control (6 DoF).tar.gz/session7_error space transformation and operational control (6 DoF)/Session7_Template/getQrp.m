function [Qrp] = getQrp(u)

% q1dp=deg2rad(u(1));
% q2dp=deg2rad(u(2));
% q3dp=deg2rad(u(3));
% Kp1=u(4);
% Kp2=u(5);
% Kp3=u(6);
% q1=u(7);
% q2=u(8);
% q3=u(9);
% q1d=deg2rad(u(10));
% q2d=deg2rad(u(11));
% q3d=deg2rad(u(12));
q1dp=u(1);
q2dp=u(2);
q3dp=u(3);
Kp1=u(4);
Kp2=u(5);
Kp3=u(6);
q1=u(7);
q2=u(8);
q3=u(9);
q1d=u(10);
q2d=u(11);
q3d=u(12);
Qdp=[q1dp;q2dp;q3dp];
Kp=[Kp1,0,0;0,Kp2,0;0,0,Kp3];
Q=[q1;q2;q3];
Q=rad2deg(Q);
Qd=[q1d;q2d;q3d];

%get Qrp
Qrp=Qdp-Kp'*(Q-Qd);%PD like
end

