syms q1 q2 q3 real;

% Specify the Robot Base (with respect to the world coordinate frame in ROS)
T0_W=eye(4)*[-1 0 0 0;0 -1 0 0;0 0 1 0;0 0 0 1];

% Compute the Homogeneous Transformations

T1_0=[ cos(q1), 0,  sin(q1),  0;
       sin(q1), 0, -cos(q1),  0;
             0, 1,        0, L1;
             0, 0,        0,  1];

T2_1=[  sin(q2), -cos(q2),  0,  L3*sin(q2);
	   -cos(q2), -sin(q2),  0, -L3*cos(q2);
              0,        0, -1,          L7;
              0,        0,  0,           1];

T3_2=[  sin(q3), 0, -cos(q3),        0;
       -cos(q3), 0, -sin(q3),        0;
              0, 1,        0, L7 - L11;
              0, 0,        0,        1];

Tcm1_0=[ cos(q1), -sin(q1), 0,  0;
         sin(q1),  cos(q1), 0,  0;
               0,        0, 1, L6;
               0,        0, 0,  1];

Tcm2_1= [  sin(q2), cos(q2), 0,  L8*sin(q2);
          -cos(q2), sin(q2), 0, -L8*cos(q2);
                 0,       0, 1,          L7;
                 0,       0, 0,           1];

Tcm3_2=[ cos(q3), -sin(q3), 0,   L10*cos(q3);
         sin(q3),  cos(q3), 0,   L10*sin(q3);
               0,        0, 1, L7 - L9 - L11;
               0,        0, 0,             1];

% Stack of Transformations

T2_0=T1_0*T2_1;
T3_0=T2_0*T3_2;

Tcm2_0=T1_0*Tcm2_1;
Tcm3_0=T2_0*Tcm3_2;

T1_W=T0_W*T1_0;
T2_W=T0_W*T2_0;
T3_W=T0_W*T3_0;

Tcm1_W=T0_W*Tcm1_0;
Tcm2_W=T0_W*Tcm2_0;
Tcm3_W=T0_W*Tcm3_0;

% Get the position of the end-effector
Xef_W=[T3_W(1:3,4);R2EulerA(T3_W(1:3,1:3))];