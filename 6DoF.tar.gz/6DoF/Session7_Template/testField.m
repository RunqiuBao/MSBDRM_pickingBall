syms q1 q2 q3 q4 q5 q6 d1 d2 d3 d4 d5 d6 dcm1 dcm2 dcm3 dcm4 dcm5 dcm6 a1 a2 a3 a4 a5 a6 acm1 acm2 acm3 acm4 acm5 t1 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 L13 real


% Jacobian of cmi.
% Relative HT
H1_0=[      cos(q1),             0,  sin(q1),                 0;
      sin(q1),             0, -cos(q1),                 0;
            0,             1,        0,                d1;
            0,             0,        0,                 1];
         
H2_1=[      cos(q2),      -sin(q2),        0,        a2*cos(q2);
      sin(q2),       cos(q2),        0,        a2*sin(q2);
            0,             0,        1,                 0;
            0,             0,        0,                 1];
        
H3_2=[      cos(q3),      -sin(q3),        0,        a3*cos(q3);
      sin(q3),       cos(q3),        0,        a3*sin(q3);
            0,             0,        1,                 0;
            0,             0,        0,                 1];
        
H4_3=[      cos(q4),             0,  sin(q4),                 0;
      sin(q4),             0, -cos(q4),                 0;
            0,             1,        0,                d4;
            0,             0,        0,                 1];
         
H5_4=[      cos(q5),             0, -sin(q5),                 0;
      sin(q5),             0,  cos(q5),                 0;
            0,            -1,        0,                d5;
            0,             0,        0,                 1];
         
H6_5=[      cos(q6),      -sin(q6),        0,                 0;
      sin(q6),       cos(q6),        0,                 0;
            0,             0,        1,                d6;
            0,             0,        0,                 1];
                                
Hcm1_0=[ cos(q1 - t1), -sin(q1 - t1),        0, acm1*cos(q1 - t1);
 sin(q1 - t1),  cos(q1 - t1),        0, acm1*sin(q1 - t1);
            0,             0,        1,              dcm1;
            0,             0,        0,                 1];

Hcm2_1=[      cos(q2),      -sin(q2),        0,      acm2*cos(q2);
      sin(q2),       cos(q2),        0,      acm2*sin(q2);
            0,             0,        1,              dcm2;
            0,             0,        0,                 1];


Hcm3_2=[      cos(q3),      -sin(q3),        0,      acm3*cos(q3);
      sin(q3),       cos(q3),        0,      acm3*sin(q3);
            0,             0,        1,              dcm3;
            0,             0,        0,                 1];
        
Hcm4_3=[     -sin(q4),      -cos(q4),        0,     -acm4*sin(q4);
      cos(q4),      -sin(q4),        0,      acm4*cos(q4);
            0,             0,        1,              dcm4;
            0,             0,        0,                 1];
        
Hcm5_4=[      sin(q5),       cos(q5),        0,      acm5*sin(q5);
     -cos(q5),       sin(q5),        0,     -acm5*cos(q5);
            0,             0,        1,              dcm5;
            0,             0,        0,                 1];
        
Hcm6_5=[     -sin(q6),      -cos(q6),        0,                 0;
      cos(q6),      -sin(q6),        0,                 0;
            0,             0,        1,              dcm6;
            0,             0,        0,                 1];
           
% Absolute HT
H2_0=simplify(H1_0*H2_1);
H3_0=simplify(H2_0*H3_2);
H4_0=simplify(H3_0*H4_3);
H5_0=simplify(H4_0*H5_4);
H6_0=simplify(H5_0*H6_5);

Hcm2_0=simplify(H1_0*Hcm2_1);
Hcm3_0=simplify(H2_0*Hcm3_2);
Hcm4_0=simplify(H3_0*Hcm4_3);
Hcm5_0=simplify(H4_0*Hcm5_4);
Hcm6_0=simplify(H5_0*Hcm6_5);