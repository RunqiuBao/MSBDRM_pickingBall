function [xd] = TrajGen_os(u)

t=u(4);
%initial state of the ef
% x1_0=0;
% x2_0=0;
% x3_0=0;
% x4_0=0;
% x5_0=0;
% x6_0=0;
% Interval between PD, PD+G, and PID+G
% Generate Different trajectories at different times
x1d=u(1);
x2d=u(2);
x3d=u(3);
x4d=deg2rad(u(4));
x5d=deg2rad(u(5));
x6d=deg2rad(u(6));

xd=[x1d;x2d;x3d;x4d;x5d;x6d];
end

