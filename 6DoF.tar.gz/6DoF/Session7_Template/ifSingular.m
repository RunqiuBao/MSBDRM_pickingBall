function [isSingular] = ifSingular(u)
q1=u(20);
q2=u(21);
q3=u(22);
L1=u(30);
L2=u(31);
L4=u(32);
L6=u(33);
L7=u(34);
L9=u(35);
L3=u(36);
L5=u(37);
L8=u(38);
L10=u(39);
L11=u(40);



end

