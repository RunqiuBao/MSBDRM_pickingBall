#include <iostream>
// ROS
#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
// OpenCV
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
// Eigen
#include <Eigen/Dense>
using namespace Eigen;

static const std::string OPENCV_WINDOW = "Image window";

class ImageConverter
{
  ros::NodeHandle nh_;
  image_transport::ImageTransport it_;
  image_transport::Subscriber image_sub_rgb;
  image_transport::Subscriber image_sub_d;
  image_transport::Subscriber image_sub_cameraMat;
  image_transport::Publisher image_pub_;

public:
  ImageConverter(): it_(nh_)
  {

      
    // Subscribe rgb from video.
    image_sub_rgb = it_.subscribe("/kinect2/sd/image_color_rect", 1, &ImageConverter::rgbCb, this);
    // Subscribe camera matrix P.
    //image_sub_cameraMat  = it_.subscribe("/kinect2/sd/camera_info", 1, &ImageConverter::cMatCb, this);
    // Subscribe depth of ball center(see below).

    // Publisher
    image_pub_ = it_.advertise("/image_converter/output_video", 1);

    cv::namedWindow(OPENCV_WINDOW);
  }

  ~ImageConverter()
  {
    cv::destroyWindow(OPENCV_WINDOW);
  }

  void rgbCb(const sensor_msgs::ImageConstPtr& msg)
  {
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }


    // detection of red ball, using hsv
    cv::Mat hsvImg;   
    cv::cvtColor(cv_ptr->image, hsvImg, CV_BGR2HSV);

    cv::Mat1b mask;
    cv::inRange(hsvImg, cv::Scalar(0, 50, 100), cv::Scalar(5, 255, 255), mask);

    cv::erode(mask, mask, cv::Mat());
    cv::dilate(mask, mask, cv::Mat());
    
    std::vector< std::vector< cv::Point > > contours;
    std::vector<cv::Vec4i> hierarchy;
    cv::findContours(mask, contours, hierarchy, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, cv::Point(0, 0) );

    /// Get the moments:
    std::vector<cv::Moments> mu(contours.size() );
    for( int i = 0; i < contours.size(); i++ ){
        mu[i] = cv::moments( contours[i], false );
    }    
    ///  Get the mass centers:
    std::vector<cv::Point2f> mc( contours.size() );
    std::vector<cv::Point2f> center( contours.size() );
    std::vector<float> radius( contours.size() );
    for( int i = 0; i < contours.size(); i++ ){
        mc[i] = cv::Point2f( mu[i].m10/mu[i].m00 , mu[i].m01/mu[i].m00 );// Estimate center of the X,Y-coordiantes in pixel
        minEnclosingCircle(contours[i], center[i], radius[i]);
    }
    // Draw bounding box(using circle):
    for( int i = 0; i< contours.size(); i++ ){
        if(radius[i] > 10){
            cv::circle( cv_ptr->image, mc[i], 3, CV_RGB(255,255,255) );
            cv::circle( cv_ptr->image, center[i], radius[i], CV_RGB(255,0,0) );
            
	    // Subscribe the depth of ball center.
            image_sub_d = it_.subscribe("/kinect2/sd/image_depth_rect", 1, boost::bind(&ImageConverter::depthCb, this, _1, center[i]) );
           
        }
     }


    // Update GUI Window
    cv::imshow(OPENCV_WINDOW, cv_ptr->image);
    cv::waitKey(3);

    // Output the modified video stream
    image_pub_.publish(cv_ptr->toImageMsg());
  }

  void depthCb(const sensor_msgs::ImageConstPtr& msg, cv::Point2f pointOfInterest)
  {
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::TYPE_16UC1);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }

    float depth = cv_ptr->image.at<ushort>(pointOfInterest);
    
    // Output center of ball and its depth.
    ROS_INFO("(%f,%f)\tDepth: %f", pointOfInterest.x, pointOfInterest.y, depth); 

    /// Reproject to 3D point.
    ///targetPos_3d=pinv(P)*[pointOfInterest.x, pointOfInterest.y,1.0];

    /// Get sacling factor from targetpos.

    /// Get the final 3D point.
    ///targetPos=targetPos(3)^-1*targetPos;

    /// Output the final 3D point.
    ROS_INFO("(%f,%f)\tTarget Position: %f", targetPos); 
    
  }

  VectorXf getTargetPos()
  {
    //Get the camera matrix P from topic /kinect2/sd/camera_info
    Matrix2Xf P(3,4);
    P<<1.0, 0.0, 0.0, 1.0;
       0.0, 1.0, 0.0, 1.0;
       0.0, 0.0, 1.0, 1.0;
    // Get the extrisic matrix from topic /kinect2/sd/camera_info
    Matrix2Xf rotationMat;  // wrt. world
    VectorXf translation;   // wrt. world
    rotationMat<<1.0, 0.0, 0.0;
                 0.0, 1.0, 0.0;
                 0.0, 0.0, 1.0;

    translation<<0.0,0.0,0.0;

    // Set the HT from base to world
    Matrix2Xf H0w;
    H0w<<1.0, 0.0, 0.0, 0.0;
         0.0, 1.0, 0.0, 0.0;
         0.0, 0.0, 1.0, 0.0;
         0.0, 0.0, 0.0, 1.0;

    // Define the reconstructured 3D point of the center of ball(Target position in Cartesian coordinates.)
    VectorXf targetPos_2d_pixel;
    VectorXf targetPos_3d;
    targetPos_2d_pixel<<0.0,0.0,0.0,1.0;

    // Reproject to get 3d target position
    targetPos_3d=P.completeOrthogonalDecomposition().pseudoInverse()*targetPos_2d_pixel;


    // Get the EulerAngle wrt. base frame.
    VectorXf eulerAngles;
    float d;

    d=pow((1-pow(rotationMat(3,1),2)),0.5);
    eulerAngles(0)=atan2(rotationMat(2,1),rotationMat(1,1));
    eulerAngles(1)=atan2(-rotationMat(3,1),d);
    eulerAngles(2)=atan2(rotationMat(3,2),rotationMat(3,3));
    // return translation and Eulerangle.
    VectorXf jointVect;
    jointVect<<targetPos_3d, eulerAngles;
    return jointVect; //eulerAngles;

  }

};


//

// Test.
/*int main(int argc, char** argv)
{
  ros::init(argc, argv, "image_converter");
  ImageConverter ic;



  ros::spin();
  return 0;
}
*/
