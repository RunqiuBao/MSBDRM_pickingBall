function [qd] = TrajGen( u )
%TRAJGEN Summary of this function goes here
%   Detailed explanation goes here

%global t0 t1 t2 t3 t4 t5 t6

t=u(4);
tf=1;%moving time
%initial state of the joints
q1_0=0;
q2_0=0;%deg2rad(90);
q3_0=0;
% Interval between PD, PD+G, and PID+G
% Generate Different trajectories at different times
q1d=u(1);
q2d=u(2);
q3d=u(3);

qd=[q1d;q2d;q3d];

end

