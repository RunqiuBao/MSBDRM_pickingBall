function [ Xout ] = SimpleRobotPlot( u )
%SIMPLEROBOTPLOT Summary of this function goes here

%%%%%FOLLOW THE INSTRUCTIONS GIVEN IN THE PDF FILE BEFORE STARTING THE
%%%%%IMPLEMENTATION
%% Joints and End-effector
% TODO: DEFINE THE Robot Base SEE FIG.6 
syms q1 q2 q3 q4 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 theta1 theta2 c real
T0_w=[0 -1 0 L1;0 0 -1 L2;1 0 0 L3;0 0 0 1];

% TODO: DEFINE THE Relative Homogeneous Transformations (symbolic form)

T1_0=[cos(q1) 0 -sin(q1) 0;sin(q1) 0 cos(q1) 0;0 -1 0 L4;0 0 0 1];
T2_1=[0 0 -1 0;-1 0 0 0;0 1 0 q2+L5+L6;0 0 0 1];
T3_2=[1 0 0 L9*cos(theta2);0 cos(pi/2+theta1) -sin(pi/2+theta1) 0;0 sin(pi/2+theta1) cos(pi/2+theta1) q3+L7+L8+L9*sin(theta2);0 0 0 1];
T4_3=[cos(-pi/2-q4) -sin(-pi/2-q4) 0 (-L12-c/2)*sin(theta1)*cos(-pi/2-q4);sin(-pi/2-q4) cos(-pi/2-q4) 0 (-L12-c/2)*sin(theta1)*sin(-pi/2-q4);0 0 1 L10+L11+(L12+c/2)*cos(theta1);0 0 0 1];

% TODO: DEFINE Homogeneous Transformations wrt BASE frame (Numeric computation)

T1_0=T1_0;
T2_0=T1_0*T2_1;
T3_0=T1_0*T2_1*T3_2;
T4_0=T1_0*T2_1*T3_2*T4_3;
T1_0=subs(T1_0,{'q1' 'q2' 'q3' 'q4' 'L1' 'L2' 'L3' 'L4' 'L5' 'L6' 'L7' 'L8' 'L9' 'L10' 'L11' 'L12' 'theta1' 'theta2' 'c'},{q1 q2 q3 q4 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 theta1 theta2 c});

% TODO: DEFINE Homogeneous Transformations wrt WORLD frame (Numeric computation)

T1_w=T0_w*T1_0;
T2_w=T0_w*T2_0;
T3_w=T0_w*T3_0;
T4_w=T0_w*T4_0;
%Joint Position (NOT NEEDED IN THIS TUTORIAL)
qp1=u(1);
qp2=u(2);
qp3=u(3);
qp4=u(4);

%Joint Velocity
q1=u(5);
q2=u(6);
q3=u(7);
q4=u(8);

%Time
t=u(9);

%Kinematic Parameters
L1=u(10);
L2=u(11);
L3=u(12);
L4=u(13);
L5=u(14);
L6=u(15);
L7=u(16);
L8=u(17);
L9=u(18);
L10=u(19);
L11=u(20);
L12=u(21);
theta1=u(22);
theta2=u(23);
c=u(24);
% ...
% TODO: add as many variable as needed, according to the robot parameters.
%Compute the POSE of end-effector with respect to the world coordinate
%frame
T0_w=subs(T0_w,{'q1' 'q2' 'q3' 'q4' 'L1' 'L2' 'L3' 'L4' 'L5' 'L6' 'L7' 'L8' 'L9' 'L10' 'L11' 'L12' 'theta1' 'theta2' 'c'},{q1 q2 q3 q4 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 theta1 theta2 c});
T1_w=subs(T1_w,{'q1' 'q2' 'q3' 'q4' 'L1' 'L2' 'L3' 'L4' 'L5' 'L6' 'L7' 'L8' 'L9' 'L10' 'L11' 'L12' 'theta1' 'theta2' 'c'},{q1 q2 q3 q4 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 theta1 theta2 c});
T2_w=subs(T2_w,{'q1' 'q2' 'q3' 'q4' 'L1' 'L2' 'L3' 'L4' 'L5' 'L6' 'L7' 'L8' 'L9' 'L10' 'L11' 'L12' 'theta1' 'theta2' 'c'},{q1 q2 q3 q4 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 theta1 theta2 c});
T3_w=subs(T3_w,{'q1' 'q2' 'q3' 'q4' 'L1' 'L2' 'L3' 'L4' 'L5' 'L6' 'L7' 'L8' 'L9' 'L10' 'L11' 'L12' 'theta1' 'theta2' 'c'},{q1 q2 q3 q4 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 theta1 theta2 c});
T4_w=subs(T4_w,{'q1' 'q2' 'q3' 'q4' 'L1' 'L2' 'L3' 'L4' 'L5' 'L6' 'L7' 'L8' 'L9' 'L10' 'L11' 'L12' 'theta1' 'theta2' 'c'},{q1 q2 q3 q4 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 theta1 theta2 c});
% TODO
Xef_W=FK_robot([q1 q2 q3 q4 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 theta1 theta2 c]);
%DRAW Base, Links, CFs and EF
%Use the functions from tutorial 1 to plot, joints, links, all CFs (base, end-effector) 

%% Centers of Mass
% TODO: Relative Homogeneous Transformations for each CM (symbolic equations)
Tcm1_0=[cos(pi/2+q1) -sin(pi/2+q1) 0 L5/2*cos(pi/2+q1);sin(pi/2+q1) cos(pi/2+q1) 0 L5/2*sin(pi/2+q1);0 0 1 L4;0 0 0 1];
Tcm2_1=[1 0 0 -L7/2;0 1 0 0;0 0 1 q2+L6/2+L5;0 0 0 1];
Tcm3_2=[cos(-atan2(L10/cos(theta1),L9*cos(theta2))) -sin(atan2(L10/cos(theta1),L9*cos(theta2))) 0 sqrt((L9*cos(theta2))^2+(L10/cos(theta1))^2)*cos(-atan2(L10/cos(theta1),L9*cos(theta2)));sin(-atan2(L10/cos(theta1),L9*cos(theta2))) cos(-atan2(L10/cos(theta1),L9*cos(theta2))) 0 sin(-atan2(L10/cos(theta1),L9*cos(theta2)))*sqrt((L9*cos(theta2))^2+(L10/cos(theta1))^2);0 0 1 q3+L7+L8+L9*sin(theta2);0 0 0 1];
Tcm4_3=[cos(-pi/2-q4) -sin(-pi/2-q4) 0 (L12+c/2)*sin(theta1)*cos(-pi/2-q4);sin(-pi/2-q4) cos(-pi/2-q4) 0 (L12+c/2)*sin(theta1)*sin(-pi/2-q4);0 0 1 L10+L11+(L12+c/2)*cos(theta1);0 0 0 1];

% TODO: Homogeneous Transformations wrt base frame (Numeric computation)
Tcm1_0=Tcm1_0;
Tcm2_0=T1_0*Tcm2_1;
Tcm3_0=T2_0*Tcm3_2;
Tcm4_0=T3_0*Tcm4_3;


% TODO: Homogeneous Transformations wrt World frame (Numeric computation)
Tcm1_w=T0_w*Tcm1_0;
Tcm2_w=T0_w*Tcm2_0;
Tcm3_w=T0_w*Tcm3_0;
Tcm4_w=T0_w*Tcm4_0;

%Joint Position (NOT NEEDED IN THIS TUTORIAL)
qp1=u(1);
qp2=u(2);
qp3=u(3);
qp4=u(4);

%Joint Velocity
q1=u(5);
q2=u(6);
q3=u(7);
q4=u(8);

%Time
t=u(9);

%Kinematic Parameters
L1=u(10);
L2=u(11);
L3=u(12);
L4=u(13);
L5=u(14);
L6=u(15);
L7=u(16);
L8=u(17);
L9=u(18);
L10=u(19);
L11=u(20);
L12=u(21);
theta1=u(22);
theta2=u(23);
c=u(24);
% ...
% TODO: add as many variable as needed, according to the robot parameters.
%DRAW CFs CMs

%TODO: Use the functions from tutoria 1 to plot CF for each center of mass
%(3 in total). Create a matlab function called plotcfs.m
Tcm1_w=subs(Tcm1_w,{'q1' 'q2' 'q3' 'q4' 'L1' 'L2' 'L3' 'L4' 'L5' 'L6' 'L7' 'L8' 'L9' 'L10' 'L11' 'L12' 'theta1' 'theta2' 'c'},{q1 q2 q3 q4 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 theta1 theta2 c});
Tcm2_w=subs(Tcm2_w,{'q1' 'q2' 'q3' 'q4' 'L1' 'L2' 'L3' 'L4' 'L5' 'L6' 'L7' 'L8' 'L9' 'L10' 'L11' 'L12' 'theta1' 'theta2' 'c'},{q1 q2 q3 q4 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 theta1 theta2 c});
Tcm3_w=subs(Tcm3_w,{'q1' 'q2' 'q3' 'q4' 'L1' 'L2' 'L3' 'L4' 'L5' 'L6' 'L7' 'L8' 'L9' 'L10' 'L11' 'L12' 'theta1' 'theta2' 'c'},{q1 q2 q3 q4 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 theta1 theta2 c});
Tcm4_w=subs(Tcm4_w,{'q1' 'q2' 'q3' 'q4' 'L1' 'L2' 'L3' 'L4' 'L5' 'L6' 'L7' 'L8' 'L9' 'L10' 'L11' 'L12' 'theta1' 'theta2' 'c'},{q1 q2 q3 q4 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 theta1 theta2 c});
% transformation_structure_2(:,:,1)=double(T0_w);
% transformation_structure_2(:,:,2)=double(T1_w);
% transformation_structure_2(:,:,2)=double(Tcm1_w);
% transformation_structure_2(:,:,3)=double(Tcm2_w);
% transformation_structure_2(:,:,4)=double(Tcm3_w);
% transformation_structure_2(:,:,5)=double(Tcm4_w);
% plotcfs(transformation_structure_2);
transformation_structure_1(:,:,1)=double(T0_w);
transformation_structure_1(:,:,2)=double(T1_w);transformation_structure_1(:,:,3)=double(Tcm1_w);
transformation_structure_1(:,:,4)=double(T2_w);transformation_structure_1(:,:,5)=double(Tcm2_w);
transformation_structure_1(:,:,6)=double(T3_w);transformation_structure_1(:,:,7)=double(Tcm3_w);
transformation_structure_1(:,:,8)=double(T4_w);

plotcfs(transformation_structure_1);

%TODO: Compute the POSE of the cm 2 with respect to the robot base (CF 0) [numeric value]
Xcm2_0=zeros(6,1);
Tcm2_0=subs(Tcm2_0,{'q1' 'q2' 'q3' 'q4' 'L1' 'L2' 'L3' 'L4' 'L5' 'L6' 'L7' 'L8' 'L9' 'L10' 'L11' 'L12' 'theta1' 'theta2' 'c'},{q1 q2 q3 q4 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 theta1 theta2 c});
Xcm2_0(1:3,1)=Tcm2_0(1:3,4);
[Xcm2_0(4,1),Xcm2_0(5,1),Xcm2_0(6,1)]=R2EulerA(Tcm2_0(1:3,1:3));
% TODO Output ONLY the position vector for end effector and cm_2 (output size 6X1) 
Xout=[Xef_W(1:3,1);Xcm2_0(1:3,1)];

end

