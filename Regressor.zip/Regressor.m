%% This script is used to get regressor.
% Make sure you have already run getEoM before you run this script!

syms theta1 theta2 theta3 theta4 theta5 theta6 theta7 theta8 theta9 real
syms theta10 theta11 theta12 theta13 theta14 theta15 theta16 theta17 theta18 theta19 real
syms theta20 theta21 theta22 theta23 theta24 theta25 theta26 theta27 theta28 real
 
%% Set the parameter vector(27 parameters).
Theta=[m2*L7^2;m2*L8^2;m2*L7*L8;...  % m2
       m3*L3^2;m3*L9^2;m3*L10^2;m3*L11^2;m3*L9*L11;m3*L3*L10;m3*L3*L9;m3*L3*L11;m3*L9*L10;m3*L10*L11;... % m3
       I133;... % I1
       I211;I222;I212;I223;I213;I233;... %I2
       I311;I312;I313;I322;I323;I333;... % I3
       m3*L3;m2*L8];  % Parameters from G.
   
%% Substitute Theta into EoM.

EoM=subs(EoM,m2*L7^2,theta1);
EoM=subs(EoM,m2*L8^2,theta2);
EoM=subs(EoM,m2*L7*L8,theta3);
EoM=subs(EoM,m3*L3^2,theta4);
EoM=subs(EoM,m3*L9^2,theta5);
EoM=subs(EoM,m3*L10^2,theta6);
EoM=subs(EoM,m3*L11^2,theta7);
EoM=subs(EoM,m3*L9*L11,theta8);
EoM=subs(EoM,m3*L3*L10,theta9);
EoM=subs(EoM,m3*L3*L9,theta10);
EoM=subs(EoM,m3*L3*L11,theta11);
EoM=subs(EoM,m3*L9*L10,theta12);
EoM=subs(EoM,m3*L10*L11,theta13);
EoM=subs(EoM,I133,theta14);
EoM=subs(EoM,I211,theta15);
EoM=subs(EoM,I222,theta16);
EoM=subs(EoM,I212,theta17);
EoM=subs(EoM,I223,theta18);
EoM=subs(EoM,I213,theta19);
EoM=subs(EoM,I233,theta20);
EoM=subs(EoM,I311,theta21);
EoM=subs(EoM,I312,theta22);
EoM=subs(EoM,I313,theta23);
EoM=subs(EoM,I322,theta24);
EoM=subs(EoM,I323,theta25);
EoM=subs(EoM,I333,theta26);
EoM=subs(EoM,m3*L3,theta27);
EoM=subs(EoM,m2*L8,theta28);

%% Get the regressor by factorizing M, C and G.

theta=[theta1; theta2; theta3; theta4; theta5; theta6; theta7; theta8; theta9;...
       theta10; theta11; theta12; theta13; theta14; theta15; theta16; theta17; theta18; theta19;...
       theta20; theta21; theta22; theta23; theta24; theta25; theta26; theta27; theta28];

Y1=jacobian(EoM(1),theta);
Y2=jacobian(EoM(2),theta);
Y3=jacobian(EoM(3),theta);

Y=[Y1;Y2;Y3];

%% Verify the regressor.
D3=simplify(Y*theta-EoM)



