#include <iostream>
#include <std_msgs/String.h>

#include "ros/ros.h"
#include "geometry_msgs/Pose.h"
#include <tf/transform_listener.h>
#include <tf/transform_broadcaster.h>


//#include <Eigen/Eigen>
//#include <Eigen/StdVector>
//#include <Eigen/Geometry>
//#include <Eigen/Core>



int main(int argc, char **argv)
{
  ros::init(argc, argv, "deg_publisher",ros::init_options::AnonymousName);
  ROS_INFO_STREAM("**Waiting for the joint_deg...");
  ros::NodeHandle nh;
  ros::Rate loop_rate(60);
  ros::Publisher degPub=nh.advertise<geometry_msgs::Pose>("deg_Yaw",1000);
  // Should be replaced with a keyboard message, see turtle tutorials.

  std::string myString;
  float theta;

  static tf::TransformBroadcaster br;
  tf::Transform transform;
  tf::Quaternion qtf;


  while(ros::ok())  // Could replaced using other flags to swithch the control mode.
  {
    ROS_INFO_STREAM("**Give me the joint_deg...");
    geometry_msgs::Pose msg;
    std::cin>>theta;   //Get desired joint_pose from keyboard.
    msg.orientation.z=theta;
    qtf.setRPY(0,0,theta);
    transform.setRotation(qtf);

    degPub.publish(msg);


  }

  return 0;
}
