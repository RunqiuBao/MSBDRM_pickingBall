#include "ros/ros.h"
#include "geometry_msgs/Pose.h"
#include "std_msgs/String.h"

void degsubCB(const std_msgs::String::ConstPtr& msg)
{
 ROS_INFO("I heard: [%s]", msg->data.c_str());
}

int main(int argc, char **argv)  // This part should be the robot_node.
{
  ros::NodeHandle n;
  ros::Subscriber sub=n.subscribe("deg_Yaw",1000,degsubCB);
  ros::spin();

  return 0;
}
