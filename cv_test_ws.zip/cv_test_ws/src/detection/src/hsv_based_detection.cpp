#include "opencv2/core/core.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <iostream>

using namespace cv;
using namespace std;

int main(int argc, char **argv)
{

  if(argc != 2)
  {
    cout<<"Usage: display_image ImageToLoadAndDisplay"<<endl;
    return -1;
  }

  Mat imgOriginal;
  Mat imgHSV;
  // Read the image from file.
  imgOriginal = imread("green_ball.jpg",CV_LOAD_IMAGE_COLOR);
  if(!imgOriginal.data)
  {
    cout<< "Could not open or find the image"<<endl;
    return -1;
  }

  // Convert an image from RGB to HSV.
  cvtColor(imgOriginal,imgHSV,COLOR_BGR2HSV);

  // Set threshold.
  int LowH=120;
  int HighH=121;
  int LowS=100;
  int HighS=101;
  int LowV=27.5;
  int HighV=68.6;
  Mat imgThresholded;
  inRange(imgHSV,Scalar(LowH,LowS,LowV),Scalar(HighH,HighS,HighV),imgThresholded);

  // Removing noise.
  erode(imgThresholded, imgThresholded, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)) );
  dilate( imgThresholded, imgThresholded, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)) );

  dilate( imgThresholded, imgThresholded, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)) );
  erode(imgThresholded, imgThresholded, getStructuringElement(MORPH_ELLIPSE, Size(5, 5)) );

  imshow("Thresholded Image", imgThresholded); //show the thresholded image
  imshow("Original", imgOriginal); //show the original image

  waitKey(0);
  return 0;
}

