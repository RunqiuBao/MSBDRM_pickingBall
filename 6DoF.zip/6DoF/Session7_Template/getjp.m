%getJp
syms q1 q2 q3 q4 q5 q6 d1 d2 d3 d4 d5 d6 dcm1 dcm2 dcm3 dcm4 dcm5 dcm6 a1 a2 a3 a4 a5 a6 acm1 acm2 acm3 acm4 acm5 t1 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 L13 real
syms q1p q2p q3p q4p q5p q6p

% Jacobian of cmi.
% Relative HT
H1_0=[      cos(q1),             0,  sin(q1),                 0;
      sin(q1),             0, -cos(q1),                 0;
            0,             1,        0,                d1;
            0,             0,        0,                 1];
         
H2_1=[      cos(q2),      -sin(q2),        0,        a2*cos(q2);
      sin(q2),       cos(q2),        0,        a2*sin(q2);
            0,             0,        1,                 0;
            0,             0,        0,                 1];
        
H3_2=[      cos(q3),      -sin(q3),        0,        a3*cos(q3);
      sin(q3),       cos(q3),        0,        a3*sin(q3);
            0,             0,        1,                 0;
            0,             0,        0,                 1];
        
H4_3=[      cos(q4),             0,  sin(q4),                 0;
      sin(q4),             0, -cos(q4),                 0;
            0,             1,        0,                d4;
            0,             0,        0,                 1];
         
H5_4=[      cos(q5),             0, -sin(q5),                 0;
      sin(q5),             0,  cos(q5),                 0;
            0,            -1,        0,                d5;
            0,             0,        0,                 1];
         
H6_5=[      cos(q6),      -sin(q6),        0,                 0;
      sin(q6),       cos(q6),        0,                 0;
            0,             0,        1,                d6;
            0,             0,        0,                 1];
                                
Hcm1_0=[ cos(q1 - t1), -sin(q1 - t1),        0, acm1*cos(q1 - t1);
 sin(q1 - t1),  cos(q1 - t1),        0, acm1*sin(q1 - t1);
            0,             0,        1,              dcm1;
            0,             0,        0,                 1];

Hcm2_1=[      cos(q2),      -sin(q2),        0,      acm2*cos(q2);
      sin(q2),       cos(q2),        0,      acm2*sin(q2);
            0,             0,        1,              dcm2;
            0,             0,        0,                 1];


Hcm3_2=[      cos(q3),      -sin(q3),        0,      acm3*cos(q3);
      sin(q3),       cos(q3),        0,      acm3*sin(q3);
            0,             0,        1,              dcm3;
            0,             0,        0,                 1];
        
Hcm4_3=[     -sin(q4),      -cos(q4),        0,     -acm4*sin(q4);
      cos(q4),      -sin(q4),        0,      acm4*cos(q4);
            0,             0,        1,              dcm4;
            0,             0,        0,                 1];
        
Hcm5_4=[      sin(q5),       cos(q5),        0,      acm5*sin(q5);
     -cos(q5),       sin(q5),        0,     -acm5*cos(q5);
            0,             0,        1,              dcm5;
            0,             0,        0,                 1];
        
Hcm6_5=[     -sin(q6),      -cos(q6),        0,                 0;
      cos(q6),      -sin(q6),        0,                 0;
            0,             0,        1,              dcm6;
            0,             0,        0,                 1];
           
% Absolute HT
H2_0=simplify(H1_0*H2_1);
H3_0=simplify(H2_0*H3_2);
H4_0=simplify(H3_0*H4_3);
H5_0=simplify(H4_0*H5_4);
H6_0=simplify(H5_0*H6_5);

Hcm2_0=simplify(H1_0*Hcm2_1);
Hcm3_0=simplify(H2_0*Hcm3_2);
Hcm4_0=simplify(H3_0*Hcm4_3);
Hcm5_0=simplify(H4_0*Hcm5_4);
Hcm6_0=simplify(H5_0*Hcm6_5);

%% Jacobian of cmi.
tcm1_0=Hcm1_0(1:3,4);
tcm2_0=Hcm2_0(1:3,4);
tcm3_0=Hcm3_0(1:3,4);
tcm4_0=Hcm4_0(1:3,4);
tcm5_0=Hcm5_0(1:3,4);
tcm6_0=Hcm6_0(1:3,4);
t1_0=H1_0(1:3,4);
t2_0=H2_0(1:3,4);
t3_0=H3_0(1:3,4);
t4_0=H4_0(1:3,4);
t5_0=H5_0(1:3,4);
t6_0=H6_0(1:3,4);

z0=sym([0;0;1]);
z1=H1_0(1:3,1:3)*z0;
z2=H2_0(1:3,1:3)*z0;
z3=H3_0(1:3,1:3)*z0;
z4=H4_0(1:3,1:3)*z0;
z5=H5_0(1:3,1:3)*z0;
z6=H6_0(1:3,1:3)*z0;

% Jcm1
Jcm11=[cross(z0,tcm1_0);z0];
Jcm12=sym(zeros(6,1));
Jcm13=sym(zeros(6,1));
Jcm14=sym(zeros(6,1));
Jcm15=sym(zeros(6,1));
Jcm16=sym(zeros(6,1));

Jcm1=[Jcm11 Jcm12 Jcm13 Jcm14 Jcm15 Jcm16 ];

% Jcm2
Jcm21=[cross(z0,tcm2_0);z0];
Jcm22=[cross(z1,(tcm2_0-t1_0));z1];
Jcm23=sym(zeros(6,1));
Jcm24=sym(zeros(6,1));
Jcm25=sym(zeros(6,1));
Jcm26=sym(zeros(6,1));

Jcm2=[Jcm21 Jcm22 Jcm23 Jcm24 Jcm25 Jcm26];
Jcm2=expand(Jcm2);
Jcm2=simplify(Jcm2);

% Jcm3
Jcm31=[cross(z0,tcm3_0);z0];
Jcm32=[cross(z1,(tcm3_0-t1_0));z1];
Jcm33=[cross(z2,(tcm3_0-t2_0));z2];
Jcm34=sym(zeros(6,1));
Jcm35=sym(zeros(6,1));
Jcm36=sym(zeros(6,1));

Jcm3=[Jcm31 Jcm32 Jcm33 Jcm34 Jcm35 Jcm36];
Jcm3=expand(Jcm3);
Jcm3=simplify(Jcm3);

% Jcm4
Jcm41=[cross(z0,tcm4_0);z0];
Jcm42=[cross(z1,(tcm4_0-t1_0));z1];
Jcm43=[cross(z2,(tcm4_0-t2_0));z2];
Jcm44=[cross(z3,(tcm4_0-t3_0));z3];
Jcm45=sym(zeros(6,1));
Jcm46=sym(zeros(6,1));

Jcm4=[Jcm41 Jcm42 Jcm43 Jcm44 Jcm45 Jcm46];
Jcm4=expand(Jcm4);
Jcm4=simplify(Jcm4);

% Jcm5
Jcm51=[cross(z0,tcm5_0);z0];
Jcm52=[cross(z1,(tcm5_0-t1_0));z1];
Jcm53=[cross(z2,(tcm5_0-t2_0));z2];
Jcm54=[cross(z3,(tcm5_0-t3_0));z3];
Jcm55=[cross(z4,(tcm5_0-t4_0));z4];
Jcm56=sym(zeros(6,1));

Jcm5=[Jcm51 Jcm52 Jcm53 Jcm54 Jcm55 Jcm56];
Jcm5=expand(Jcm5);
Jcm5=simplify(Jcm5);

% Jcm6
Jcm61=[cross(z0,tcm6_0);z0];
Jcm62=[cross(z1,(tcm6_0-t1_0));z1];
Jcm63=[cross(z2,(tcm6_0-t2_0));z2];
Jcm64=[cross(z3,(tcm6_0-t3_0));z3];
Jcm65=[cross(z4,(tcm6_0-t4_0));z4];
Jcm66=[cross(z5,(tcm6_0-t5_0));z5];

Jcm6=[Jcm61 Jcm62 Jcm63 Jcm64 Jcm65 Jcm66];
Jcm6=expand(Jcm6);
Jcm6=simplify(Jcm6);

% Complete the Jacobian Matrix (symbolic form)
J1=[cross(z0,t6_0);z0];
J2=[cross(z1,(t6_0-t1_0));z1];
J3=[cross(z2,(t6_0-t2_0));z2];
J4=[cross(z3,t6_0-t3_0);z3];
J5=[cross(z4,(t6_0-t4_0));z4];
J6=[cross(z5,(t6_0-t5_0));z5];
%% 
% 
% Jef1=[ (sin(q1 + q2 + q3)*abs(L5 - L12))/2 + (L4*cos(q1 + q5))/2 + (L13*cos(q1 + q5))/2 + (L3*sin(q1 + q2))/2 + 2*L2*cos(q1) + L4*cos(q1) - L11*cos(q1) + L13*cos(q1) - (sin(q2 - q1 + q3)*abs(L5 - L12))/2 + (L4*cos(q1 - q5))/2 + (L13*cos(q1 - q5))/2 + (L3*sin(q1 - q2))/2 + (L4*cos(q1 + q2 + q3 + q4 - q5)*abs(L5 - L12))/(4*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L4*cos(q2 - q1 + q3 + q4 + q5)*abs(L5 - L12))/(4*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L13*cos(q1 + q2 + q3 + q4 - q5)*abs(L5 - L12))/(4*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L13*cos(q2 - q1 + q3 + q4 + q5)*abs(L5 - L12))/(4*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L12*cos(q1 + q2 + q3)*abs(L5 - L12))/(2*(L5 - L12)) + (L12*cos(q1 + q2 + q3 + q4)*abs(L5 - L12))/(2*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L4*cos(q2 - q1 + q3 + q4 - q5)*abs(L5 - L12))/(4*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L13*cos(q2 - q1 + q3 + q4 - q5)*abs(L5 - L12))/(4*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L12*cos(q2 - q1 + q3)*abs(L5 - L12))/(2*(L5 - L12)) - (L12*abs(L5 - L12)*cos(q2 - q1 + q3 + q4))/(2*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L4*abs(L5 - L12)*cos(q1 + q2 + q3 + q4 + q5))/(4*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L13*abs(L5 - L12)*cos(q1 + q2 + q3 + q4 + q5))/(4*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L12^2*sin(q1 + q2 + q3 + q4)*abs(L5 - L12))/(2*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L12^2*abs(L5 - L12)*sin(q2 - q1 + q3 + q4))/(2*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L4*L12*sin(q1 + q2 + q3 + q4 - q5)*abs(L5 - L12))/(4*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L4*L12*sin(q2 - q1 + q3 + q4 + q5)*abs(L5 - L12))/(4*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L12*L13*sin(q1 + q2 + q3 + q4 - q5)*abs(L5 - L12))/(4*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L12*L13*sin(q2 - q1 + q3 + q4 + q5)*abs(L5 - L12))/(4*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L4*L12*abs(L5 - L12)*sin(q2 - q1 + q3 + q4 - q5))/(4*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L12*L13*abs(L5 - L12)*sin(q2 - q1 + q3 + q4 - q5))/(4*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L4*L12*sin(q1 + q2 + q3 + q4 + q5)*abs(L5 - L12))/(4*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L12*L13*sin(q1 + q2 + q3 + q4 + q5)*abs(L5 - L12))/(4*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)), -(abs(L5 - L12)*cos(q1)*(L12^2*cos(q2 + q3 + q4) + L12^2*sin(q2 + q3 + q4) - L5*L12*cos(q2 + q3 + q4) + (L4*L5*cos(q2 + q3 + q4 + q5))/2 - (L4*L12*cos(q2 + q3 + q4 + q5))/2 + (L5*L13*cos(q2 + q3 + q4 + q5))/2 - (L12*L13*cos(q2 + q3 + q4 + q5))/2 - (L4*L12*sin(q2 + q3 + q4 + q5))/2 - (L12*L13*sin(q2 + q3 + q4 + q5))/2 - L12*cos(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) - L5*sin(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) + L12*sin(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) - (L4*L5*cos(q2 + q3 + q4 - q5))/2 + (L4*L12*cos(q2 + q3 + q4 - q5))/2 - (L5*L13*cos(q2 + q3 + q4 - q5))/2 + (L12*L13*cos(q2 + q3 + q4 - q5))/2 + (L4*L12*sin(q2 + q3 + q4 - q5))/2 + (L12*L13*sin(q2 + q3 + q4 - q5))/2 - (L3*L5*sin(q2)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2))/abs(L5 - L12) + (L3*L12*sin(q2)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2))/abs(L5 - L12)))/((L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)), -(abs(L5 - L12)*cos(q1)*(L12^2*cos(q2 + q3 + q4) + L12^2*sin(q2 + q3 + q4) - L5*L12*cos(q2 + q3 + q4) + (L4*L5*cos(q2 + q3 + q4 + q5))/2 - (L4*L12*cos(q2 + q3 + q4 + q5))/2 + (L5*L13*cos(q2 + q3 + q4 + q5))/2 - (L12*L13*cos(q2 + q3 + q4 + q5))/2 - (L4*L12*sin(q2 + q3 + q4 + q5))/2 - (L12*L13*sin(q2 + q3 + q4 + q5))/2 - L12*cos(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) - L5*sin(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) + L12*sin(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) - (L4*L5*cos(q2 + q3 + q4 - q5))/2 + (L4*L12*cos(q2 + q3 + q4 - q5))/2 - (L5*L13*cos(q2 + q3 + q4 - q5))/2 + (L12*L13*cos(q2 + q3 + q4 - q5))/2 + (L4*L12*sin(q2 + q3 + q4 - q5))/2 + (L12*L13*sin(q2 + q3 + q4 - q5))/2))/((L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2));
%        (L4*sin(q1 + q5))/2 - (L3*cos(q1 + q2))/2 - (cos(q1 + q2 + q3)*abs(L5 - L12))/2 + (L13*sin(q1 + q5))/2 - (cos(q2 - q1 + q3)*abs(L5 - L12))/2 + 2*L2*sin(q1) + L4*sin(q1) - L11*sin(q1) + L13*sin(q1) - (L3*cos(q1 - q2))/2 + (L4*sin(q1 - q5))/2 + (L13*sin(q1 - q5))/2 + (L4*sin(q1 + q2 + q3 + q4 - q5)*abs(L5 - L12))/(4*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L4*sin(q2 - q1 + q3 + q4 + q5)*abs(L5 - L12))/(4*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L13*sin(q1 + q2 + q3 + q4 - q5)*abs(L5 - L12))/(4*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L13*sin(q2 - q1 + q3 + q4 + q5)*abs(L5 - L12))/(4*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L12*sin(q1 + q2 + q3)*abs(L5 - L12))/(2*(L5 - L12)) + (L12*sin(q1 + q2 + q3 + q4)*abs(L5 - L12))/(2*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L4*abs(L5 - L12)*sin(q2 - q1 + q3 + q4 - q5))/(4*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L13*abs(L5 - L12)*sin(q2 - q1 + q3 + q4 - q5))/(4*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L12*sin(q2 - q1 + q3)*abs(L5 - L12))/(2*(L5 - L12)) + (L12*abs(L5 - L12)*sin(q2 - q1 + q3 + q4))/(2*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L4*sin(q1 + q2 + q3 + q4 + q5)*abs(L5 - L12))/(4*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L13*sin(q1 + q2 + q3 + q4 + q5)*abs(L5 - L12))/(4*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L12^2*cos(q1 + q2 + q3 + q4)*abs(L5 - L12))/(2*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L12^2*abs(L5 - L12)*cos(q2 - q1 + q3 + q4))/(2*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L4*L12*cos(q1 + q2 + q3 + q4 - q5)*abs(L5 - L12))/(4*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L4*L12*cos(q2 - q1 + q3 + q4 + q5)*abs(L5 - L12))/(4*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L12*L13*cos(q1 + q2 + q3 + q4 - q5)*abs(L5 - L12))/(4*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L12*L13*cos(q2 - q1 + q3 + q4 + q5)*abs(L5 - L12))/(4*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L4*L12*cos(q2 - q1 + q3 + q4 - q5)*abs(L5 - L12))/(4*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) + (L12*L13*cos(q2 - q1 + q3 + q4 - q5)*abs(L5 - L12))/(4*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L4*L12*abs(L5 - L12)*cos(q1 + q2 + q3 + q4 + q5))/(4*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)) - (L12*L13*abs(L5 - L12)*cos(q1 + q2 + q3 + q4 + q5))/(4*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)), -(abs(L5 - L12)*sin(q1)*(L12^2*cos(q2 + q3 + q4) + L12^2*sin(q2 + q3 + q4) - L5*L12*cos(q2 + q3 + q4) + (L4*L5*cos(q2 + q3 + q4 + q5))/2 - (L4*L12*cos(q2 + q3 + q4 + q5))/2 + (L5*L13*cos(q2 + q3 + q4 + q5))/2 - (L12*L13*cos(q2 + q3 + q4 + q5))/2 - (L4*L12*sin(q2 + q3 + q4 + q5))/2 - (L12*L13*sin(q2 + q3 + q4 + q5))/2 - L12*cos(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) - L5*sin(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) + L12*sin(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) - (L4*L5*cos(q2 + q3 + q4 - q5))/2 + (L4*L12*cos(q2 + q3 + q4 - q5))/2 - (L5*L13*cos(q2 + q3 + q4 - q5))/2 + (L12*L13*cos(q2 + q3 + q4 - q5))/2 + (L4*L12*sin(q2 + q3 + q4 - q5))/2 + (L12*L13*sin(q2 + q3 + q4 - q5))/2 - (L3*L5*sin(q2)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2))/abs(L5 - L12) + (L3*L12*sin(q2)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2))/abs(L5 - L12)))/((L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)), -(abs(L5 - L12)*sin(q1)*(L12^2*cos(q2 + q3 + q4) + L12^2*sin(q2 + q3 + q4) - L5*L12*cos(q2 + q3 + q4) + (L4*L5*cos(q2 + q3 + q4 + q5))/2 - (L4*L12*cos(q2 + q3 + q4 + q5))/2 + (L5*L13*cos(q2 + q3 + q4 + q5))/2 - (L12*L13*cos(q2 + q3 + q4 + q5))/2 - (L4*L12*sin(q2 + q3 + q4 + q5))/2 - (L12*L13*sin(q2 + q3 + q4 + q5))/2 - L12*cos(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) - L5*sin(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) + L12*sin(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) - (L4*L5*cos(q2 + q3 + q4 - q5))/2 + (L4*L12*cos(q2 + q3 + q4 - q5))/2 - (L5*L13*cos(q2 + q3 + q4 - q5))/2 + (L12*L13*cos(q2 + q3 + q4 - q5))/2 + (L4*L12*sin(q2 + q3 + q4 - q5))/2 + (L12*L13*sin(q2 + q3 + q4 - q5))/2))/((L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2));
%        0,                                        (abs(L5 - L12)*(2*L12^2*cos(q2 + q3 + q4) - 2*L12^2*sin(q2 + q3 + q4) + 2*L5*L12*sin(q2 + q3 + q4) - L4*L12*cos(q2 + q3 + q4 + q5) - L12*L13*cos(q2 + q3 + q4 + q5) - L4*L5*sin(q2 + q3 + q4 + q5) + L4*L12*sin(q2 + q3 + q4 + q5) - L5*L13*sin(q2 + q3 + q4 + q5) + L12*L13*sin(q2 + q3 + q4 + q5) - 2*L5*cos(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) + 2*L12*cos(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) + 2*L12*sin(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) + L4*L12*cos(q2 + q3 + q4 - q5) + L12*L13*cos(q2 + q3 + q4 - q5) + L4*L5*sin(q2 + q3 + q4 - q5) - L4*L12*sin(q2 + q3 + q4 - q5) + L5*L13*sin(q2 + q3 + q4 - q5) - L12*L13*sin(q2 + q3 + q4 - q5) - (2*L3*L5*cos(q2)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2))/abs(L5 - L12) + (2*L3*L12*cos(q2)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2))/abs(L5 - L12)))/(2*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)),                                            (abs(L5 - L12)*(2*L12^2*cos(q2 + q3 + q4) - 2*L12^2*sin(q2 + q3 + q4) + 2*L5*L12*sin(q2 + q3 + q4) - L4*L12*cos(q2 + q3 + q4 + q5) - L12*L13*cos(q2 + q3 + q4 + q5) - L4*L5*sin(q2 + q3 + q4 + q5) + L4*L12*sin(q2 + q3 + q4 + q5) - L5*L13*sin(q2 + q3 + q4 + q5) + L12*L13*sin(q2 + q3 + q4 + q5) - 2*L5*cos(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) + 2*L12*cos(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) + 2*L12*sin(q2 + q3)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) + L4*L12*cos(q2 + q3 + q4 - q5) + L12*L13*cos(q2 + q3 + q4 - q5) + L4*L5*sin(q2 + q3 + q4 - q5) - L4*L12*sin(q2 + q3 + q4 - q5) + L5*L13*sin(q2 + q3 + q4 - q5) - L12*L13*sin(q2 + q3 + q4 - q5)))/(2*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2));
%        0,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     sin(q1),                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                sin(q1);
%        0,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    -cos(q1),                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               -cos(q1);
%        1,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           0,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      0];
% Jef2=[-(abs(L5 - L12)*cos(q1)*(L12^2*cos(q2 + q3 + q4) + L12^2*sin(q2 + q3 + q4) - L5*L12*cos(q2 + q3 + q4) + (L4*L5*cos(q2 + q3 + q4 + q5))/2 - (L4*L12*cos(q2 + q3 + q4 + q5))/2 + (L5*L13*cos(q2 + q3 + q4 + q5))/2 - (L12*L13*cos(q2 + q3 + q4 + q5))/2 - (L4*L12*sin(q2 + q3 + q4 + q5))/2 - (L12*L13*sin(q2 + q3 + q4 + q5))/2 - (L4*L5*cos(q2 + q3 + q4 - q5))/2 + (L4*L12*cos(q2 + q3 + q4 - q5))/2 - (L5*L13*cos(q2 + q3 + q4 - q5))/2 + (L12*L13*cos(q2 + q3 + q4 - q5))/2 + (L4*L12*sin(q2 + q3 + q4 - q5))/2 + (L12*L13*sin(q2 + q3 + q4 - q5))/2))/((L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)), (abs(L5 - L12)*(L4 + L13)*((L12*sin(q1)*sin(q5)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2))/abs(L5 - L12) - (L5*sin(q1)*sin(q5)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2))/abs(L5 - L12) - L12*cos(q1)*cos(q5)*sin(q2)*sin(q3)*sin(q4) - L5*cos(q1)*cos(q2)*cos(q3)*cos(q4)*cos(q5) + L12*cos(q1)*cos(q2)*cos(q3)*cos(q4)*cos(q5) + L12*cos(q1)*cos(q2)*cos(q3)*cos(q5)*sin(q4) + L12*cos(q1)*cos(q2)*cos(q4)*cos(q5)*sin(q3) + L12*cos(q1)*cos(q3)*cos(q4)*cos(q5)*sin(q2) + L5*cos(q1)*cos(q2)*cos(q5)*sin(q3)*sin(q4) + L5*cos(q1)*cos(q3)*cos(q5)*sin(q2)*sin(q4) + L5*cos(q1)*cos(q4)*cos(q5)*sin(q2)*sin(q3) - L12*cos(q1)*cos(q2)*cos(q5)*sin(q3)*sin(q4) - L12*cos(q1)*cos(q3)*cos(q5)*sin(q2)*sin(q4) - L12*cos(q1)*cos(q4)*cos(q5)*sin(q2)*sin(q3)))/((L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)),                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 0;
%       -(abs(L5 - L12)*sin(q1)*(L12^2*cos(q2 + q3 + q4) + L12^2*sin(q2 + q3 + q4) - L5*L12*cos(q2 + q3 + q4) + (L4*L5*cos(q2 + q3 + q4 + q5))/2 - (L4*L12*cos(q2 + q3 + q4 + q5))/2 + (L5*L13*cos(q2 + q3 + q4 + q5))/2 - (L12*L13*cos(q2 + q3 + q4 + q5))/2 - (L4*L12*sin(q2 + q3 + q4 + q5))/2 - (L12*L13*sin(q2 + q3 + q4 + q5))/2 - (L4*L5*cos(q2 + q3 + q4 - q5))/2 + (L4*L12*cos(q2 + q3 + q4 - q5))/2 - (L5*L13*cos(q2 + q3 + q4 - q5))/2 + (L12*L13*cos(q2 + q3 + q4 - q5))/2 + (L4*L12*sin(q2 + q3 + q4 - q5))/2 + (L12*L13*sin(q2 + q3 + q4 - q5))/2))/((L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)), (abs(L5 - L12)*(L4 + L13)*((L5*cos(q1)*sin(q5)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2))/abs(L5 - L12) - (L12*cos(q1)*sin(q5)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2))/abs(L5 - L12) + L5*cos(q2)*cos(q5)*sin(q1)*sin(q3)*sin(q4) + L5*cos(q3)*cos(q5)*sin(q1)*sin(q2)*sin(q4) + L5*cos(q4)*cos(q5)*sin(q1)*sin(q2)*sin(q3) - L12*cos(q2)*cos(q5)*sin(q1)*sin(q3)*sin(q4) - L12*cos(q3)*cos(q5)*sin(q1)*sin(q2)*sin(q4) - L12*cos(q4)*cos(q5)*sin(q1)*sin(q2)*sin(q3) - L12*cos(q5)*sin(q1)*sin(q2)*sin(q3)*sin(q4) - L5*cos(q2)*cos(q3)*cos(q4)*cos(q5)*sin(q1) + L12*cos(q2)*cos(q3)*cos(q4)*cos(q5)*sin(q1) + L12*cos(q2)*cos(q3)*cos(q5)*sin(q1)*sin(q4) + L12*cos(q2)*cos(q4)*cos(q5)*sin(q1)*sin(q3) + L12*cos(q3)*cos(q4)*cos(q5)*sin(q1)*sin(q2)))/((L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)),                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 0;
%       (abs(L5 - L12)*(2*L12^2*cos(q2 + q3 + q4) - 2*L12^2*sin(q2 + q3 + q4) + 2*L5*L12*sin(q2 + q3 + q4) - L4*L12*cos(q2 + q3 + q4 + q5) - L12*L13*cos(q2 + q3 + q4 + q5) - L4*L5*sin(q2 + q3 + q4 + q5) + L4*L12*sin(q2 + q3 + q4 + q5) - L5*L13*sin(q2 + q3 + q4 + q5) + L12*L13*sin(q2 + q3 + q4 + q5) + L4*L12*cos(q2 + q3 + q4 - q5) + L12*L13*cos(q2 + q3 + q4 - q5) + L4*L5*sin(q2 + q3 + q4 - q5) - L4*L12*sin(q2 + q3 + q4 - q5) + L5*L13*sin(q2 + q3 + q4 - q5) - L12*L13*sin(q2 + q3 + q4 - q5)))/(2*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)),                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     -(abs(L5 - L12)*(L4 + L13)*(L12*cos(q2 + q3 + q4 + q5) + L5*sin(q2 + q3 + q4 + q5) - L12*sin(q2 + q3 + q4 + q5) + L12*cos(q2 + q3 + q4 - q5) + L5*sin(q2 + q3 + q4 - q5) - L12*sin(q2 + q3 + q4 - q5)))/(2*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)),                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 0;
%       sin(q1),                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 (abs(L5 - L12)*(L12*cos(q1 + q2 + q3 + q4) + L5*sin(q1 + q2 + q3 + q4) - L12*sin(q1 + q2 + q3 + q4) + L12*cos(q2 - q1 + q3 + q4) + L5*sin(q2 - q1 + q3 + q4) - L12*sin(q2 - q1 + q3 + q4)))/(2*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)), (abs(L5 - L12)*((L5*cos(q5)*sin(q1)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2))/abs(L5 - L12) - (L12*cos(q5)*sin(q1)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2))/abs(L5 - L12) + L5*cos(q1)*cos(q2)*sin(q3)*sin(q4)*sin(q5) + L5*cos(q1)*cos(q3)*sin(q2)*sin(q4)*sin(q5) + L5*cos(q1)*cos(q4)*sin(q2)*sin(q3)*sin(q5) - L12*cos(q1)*cos(q2)*sin(q3)*sin(q4)*sin(q5) - L12*cos(q1)*cos(q3)*sin(q2)*sin(q4)*sin(q5) - L12*cos(q1)*cos(q4)*sin(q2)*sin(q3)*sin(q5) - L12*cos(q1)*sin(q2)*sin(q3)*sin(q4)*sin(q5) - L5*cos(q1)*cos(q2)*cos(q3)*cos(q4)*sin(q5) + L12*cos(q1)*cos(q2)*cos(q3)*cos(q4)*sin(q5) + L12*cos(q1)*cos(q2)*cos(q3)*sin(q4)*sin(q5) + L12*cos(q1)*cos(q2)*cos(q4)*sin(q3)*sin(q5) + L12*cos(q1)*cos(q3)*cos(q4)*sin(q2)*sin(q5)))/((L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2));
%       -cos(q1),                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                -(abs(L5 - L12)*(L5*cos(q1 + q2 + q3 + q4) - L12*cos(q1 + q2 + q3 + q4) - L12*sin(q1 + q2 + q3 + q4) - L5*cos(q2 - q1 + q3 + q4) + L12*cos(q2 - q1 + q3 + q4) + L12*sin(q2 - q1 + q3 + q4)))/(2*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)), (abs(L5 - L12)*((L12*cos(q1)*cos(q5)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2))/abs(L5 - L12) - (L5*cos(q1)*cos(q5)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2))/abs(L5 - L12) + L12*cos(q2)*cos(q3)*sin(q1)*sin(q4)*sin(q5) + L12*cos(q2)*cos(q4)*sin(q1)*sin(q3)*sin(q5) + L12*cos(q3)*cos(q4)*sin(q1)*sin(q2)*sin(q5) + L5*cos(q2)*sin(q1)*sin(q3)*sin(q4)*sin(q5) + L5*cos(q3)*sin(q1)*sin(q2)*sin(q4)*sin(q5) + L5*cos(q4)*sin(q1)*sin(q2)*sin(q3)*sin(q5) - L12*cos(q2)*sin(q1)*sin(q3)*sin(q4)*sin(q5) - L12*cos(q3)*sin(q1)*sin(q2)*sin(q4)*sin(q5) - L12*cos(q4)*sin(q1)*sin(q2)*sin(q3)*sin(q5) - L12*sin(q1)*sin(q2)*sin(q3)*sin(q4)*sin(q5) - L5*cos(q2)*cos(q3)*cos(q4)*sin(q1)*sin(q5) + L12*cos(q2)*cos(q3)*cos(q4)*sin(q1)*sin(q5)))/((L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2));
%       0,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        (abs(L5 - L12)*(L12*cos(q2 + q3 + q4) - L5*cos(q2 + q3 + q4) + L12*sin(q2 + q3 + q4)))/((L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2)),                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      (abs(L5 - L12)*(L5*cos(q2 + q3 + q4 + q5) - L12*cos(q2 + q3 + q4 + q5) - L12*sin(q2 + q3 + q4 + q5) - L5*cos(q2 + q3 + q4 - q5) + L12*cos(q2 + q3 + q4 - q5) + L12*sin(q2 + q3 + q4 - q5)))/(2*(L5 - L12)*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2))];
% Jef=[Jef1,Jef2];
Jef=[ d4*cos(q1) + d6*cos(q1)*cos(q5) - a2*cos(q2)*sin(q1) - a3*cos(q2)*cos(q3)*sin(q1) + a3*sin(q1)*sin(q2)*sin(q3) - d5*cos(q2)*cos(q3)*sin(q1)*sin(q4) - d5*cos(q2)*cos(q4)*sin(q1)*sin(q3) - d5*cos(q3)*cos(q4)*sin(q1)*sin(q2) + d5*sin(q1)*sin(q2)*sin(q3)*sin(q4) + d6*cos(q2)*cos(q3)*cos(q4)*sin(q1)*sin(q5) - d6*cos(q2)*sin(q1)*sin(q3)*sin(q4)*sin(q5) - d6*cos(q3)*sin(q1)*sin(q2)*sin(q4)*sin(q5) - d6*cos(q4)*sin(q1)*sin(q2)*sin(q3)*sin(q5), -cos(q1)*((d6*cos(q2 + q3 + q4 + q5))/2 + a3*sin(q2 + q3) + a2*sin(q2) - (d6*cos(q2 + q3 + q4 - q5))/2 - d5*cos(q2 + q3 + q4)), -cos(q1)*((d6*cos(q2 + q3 + q4 + q5))/2 + a3*sin(q2 + q3) - (d6*cos(q2 + q3 + q4 - q5))/2 - d5*cos(q2 + q3 + q4)), cos(q1)*((d6*cos(q2 + q3 + q4 - q5))/2 - (d6*cos(q2 + q3 + q4 + q5))/2 + d5*cos(q2 + q3 + q4)), d6*cos(q1)*cos(q2)*cos(q5)*sin(q3)*sin(q4) - d6*sin(q1)*sin(q5) + d6*cos(q1)*cos(q3)*cos(q5)*sin(q2)*sin(q4) + d6*cos(q1)*cos(q4)*cos(q5)*sin(q2)*sin(q3) - d6*cos(q1)*cos(q2)*cos(q3)*cos(q4)*cos(q5),                                                                                                                                                                                       0;
 d4*sin(q1) + a2*cos(q1)*cos(q2) + d6*cos(q5)*sin(q1) + a3*cos(q1)*cos(q2)*cos(q3) - a3*cos(q1)*sin(q2)*sin(q3) + d5*cos(q1)*cos(q2)*cos(q3)*sin(q4) + d5*cos(q1)*cos(q2)*cos(q4)*sin(q3) + d5*cos(q1)*cos(q3)*cos(q4)*sin(q2) - d5*cos(q1)*sin(q2)*sin(q3)*sin(q4) + d6*cos(q1)*cos(q2)*sin(q3)*sin(q4)*sin(q5) + d6*cos(q1)*cos(q3)*sin(q2)*sin(q4)*sin(q5) + d6*cos(q1)*cos(q4)*sin(q2)*sin(q3)*sin(q5) - d6*cos(q1)*cos(q2)*cos(q3)*cos(q4)*sin(q5), -sin(q1)*((d6*cos(q2 + q3 + q4 + q5))/2 + a3*sin(q2 + q3) + a2*sin(q2) - (d6*cos(q2 + q3 + q4 - q5))/2 - d5*cos(q2 + q3 + q4)), -sin(q1)*((d6*cos(q2 + q3 + q4 + q5))/2 + a3*sin(q2 + q3) - (d6*cos(q2 + q3 + q4 - q5))/2 - d5*cos(q2 + q3 + q4)), sin(q1)*((d6*cos(q2 + q3 + q4 - q5))/2 - (d6*cos(q2 + q3 + q4 + q5))/2 + d5*cos(q2 + q3 + q4)), d6*cos(q1)*sin(q5) + d6*cos(q2)*cos(q5)*sin(q1)*sin(q3)*sin(q4) + d6*cos(q3)*cos(q5)*sin(q1)*sin(q2)*sin(q4) + d6*cos(q4)*cos(q5)*sin(q1)*sin(q2)*sin(q3) - d6*cos(q2)*cos(q3)*cos(q4)*cos(q5)*sin(q1),                                                                                                                                                                                       0;
                                                                                                                                                                                                                                                                                                                                                                                                                                                      0,            a3*cos(q2 + q3) - (d6*sin(q2 + q3 + q4 + q5))/2 + a2*cos(q2) + (d6*sin(q2 + q3 + q4 - q5))/2 + d5*sin(q2 + q3 + q4),            a3*cos(q2 + q3) - (d6*sin(q2 + q3 + q4 + q5))/2 + (d6*sin(q2 + q3 + q4 - q5))/2 + d5*sin(q2 + q3 + q4),           (d6*sin(q2 + q3 + q4 - q5))/2 - (d6*sin(q2 + q3 + q4 + q5))/2 + d5*sin(q2 + q3 + q4),                                                                                                                                              -(d6*(sin(q2 + q3 + q4 + q5) + sin(q2 + q3 + q4 - q5)))/2,                                                                                                                                                                                       0;
                                                                                                                                                                                                                                                                                                                                                                                                                                                      0,                                                                                                                        sin(q1),                                                                                                           sin(q1),                                                                                        sin(q1),                                                                                                                                                    sin(q1 + q2 + q3 + q4)/2 + sin(q2 - q1 + q3 + q4)/2, cos(q5)*sin(q1) - cos(q1)*cos(q2)*cos(q3)*cos(q4)*sin(q5) + cos(q1)*cos(q2)*sin(q3)*sin(q4)*sin(q5) + cos(q1)*cos(q3)*sin(q2)*sin(q4)*sin(q5) + cos(q1)*cos(q4)*sin(q2)*sin(q3)*sin(q5);
                                                                                                                                                                                                                                                                                                                                                                                                                                                      0,                                                                                                                       -cos(q1),                                                                                                          -cos(q1),                                                                                       -cos(q1),                                                                                                                                                    cos(q2 - q1 + q3 + q4)/2 - cos(q1 + q2 + q3 + q4)/2, cos(q2)*sin(q1)*sin(q3)*sin(q4)*sin(q5) - cos(q2)*cos(q3)*cos(q4)*sin(q1)*sin(q5) - cos(q1)*cos(q5) + cos(q3)*sin(q1)*sin(q2)*sin(q4)*sin(q5) + cos(q4)*sin(q1)*sin(q2)*sin(q3)*sin(q5);
                                                                                                                                                                                                                                                                                                                                                                                                                                                      1,                                                                                                                              0,                                                                                                                 0,                                                                                              0,                                                                                                                                                                                     -cos(q2 + q3 + q4),                                                                                                                                     cos(q2 + q3 + q4 + q5)/2 - cos(q2 + q3 + q4 - q5)/2];
 Jef=subs(Jef,{'d1' 'd2' 'd3' 'd4' 'd5' 'd6' 'dcm1' 'dcm2' 'dcm3' 'dcm4' 'dcm5' 'dcm6' 'a1' 'a2' 'a3' 'a4' 'a5' 'a6' 'acm1' 'acm2' 'acm3' 'acm4' 'acm5' 't1' 'm1' 'm2' 'm3' 'm4' 'm5' 'm6' 'g'},{0.1273 0 0 0.163941 0.1157 0.0922 0.1273 0.158 0.068 0.170941 0.1087 0.0662 0 -0.612 -0.5723 0 0 0 0.0342 -0.232 -0.3323 -0.018 -0.018 0.9098 7.1 12.7 4.27 2 2 0.365 9.81});
 Jef=expand(Jef);
 Jef=simplify(Jef);
 Jp=diff(Jef,q1)*q1p+diff(Jef,q2)*q2p+diff(Jef,q3)*q3p+diff(Jef,q4)*q4p+diff(Jef,q5)*q5p+diff(Jef,q6)*q6p;
 Jp=simplify(Jp);