%function [D_symbolic]=model(u)
syms q1 q2 q3 q4 q5 q6 d1 d2 d3 d4 d5 d6 dcm1 dcm2 dcm3 dcm4 dcm5 dcm6 a1 a2 a3 a4 a5 a6 acm1 acm2 acm3 acm4 acm5 t1 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 L13 real

D_symbolic(1,:)=[q1, d1, 0, sym(pi/2)];
D_symbolic(2,:)=[q2, 0, a2, 0];
D_symbolic(3,:)=[q3, 0, a3, 0];
D_symbolic(4,:)=[q4, d4, 0, sym(pi/2)];
D_symbolic(5,:)=[q5, d5, 0, sym(-pi/2)];
D_symbolic(6,:)=[q6, d6, 0, 0];


% DH of center of mass
D_symbolic(7,:)=[q1-t1,dcm1 , acm1, 0];
D_symbolic(8,:)=[q2, dcm2, acm2, 0];
D_symbolic(9,:)=[q3, dcm3, acm3, 0];
D_symbolic(10,:)=[q4+sym(pi/2),dcm4 , acm4, 0];
D_symbolic(11,:)=[q5-sym(pi/2), dcm5, acm5, 0];
D_symbolic(12,:)=[q6+sym(pi/2), dcm6, 0, 0];


%end