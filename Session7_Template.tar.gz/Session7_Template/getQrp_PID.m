function [Qrp] = getQrp_PID(u)
q1dp=u(1);
q2dp=u(2);
q3dp=u(3);
Kp1=u(4);
Kp2=u(5);
Kp3=u(6);
Dq1=u(7);
Dq2=u(8);
Dq3=u(9);
In_Dq1=u(10);
In_Dq2=u(11);
In_Dq3=u(12);
Ki1=u(13);
Ki2=u(14);
Ki3=u(15);
Ki=[u(13),0,0;0,u(14),0;0,0,u(15)];
DeltaQ=[Dq1;Dq2;Dq3];
Integral_DeltaQ=[In_Dq1;In_Dq2;In_Dq3];
Qdp=[q1dp;q2dp;q3dp];
Kp=[Kp1,0,0;0,Kp2,0;0,0,Kp3];

%get Qrp
Qrp=Qdp-Kp'*DeltaQ-Ki*Integral_DeltaQ;

end

