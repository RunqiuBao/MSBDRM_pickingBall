function [Qrp] = getQrp_os_PD(u)
q1=deg2rad(u(20));
q2=deg2rad(u(21));
q3=deg2rad(u(22));
% %Robot Parameters
% 
m1=u(26);
m2=u(27);
m3=u(28);
g=u(29);

L1=u(30);
L2=u(31);
L4=u(32);
L6=u(33);
L7=u(34);
L9=u(35);
L3=u(36);
L5=u(37);
L8=u(38);
L10=u(39);
L11=u(40);

%robot jacobian
Jef =[L11*cos(q1) + L3*sin(q1)*sin(q2),                                                                     -L3*cos(q1)*cos(q2),                                                                       0;
      L11*sin(q1) - L3*cos(q1)*sin(q2),                                                                     -L3*cos(q2)*sin(q1),                                                                       0;
                                     0, cos(q1)*(L11*sin(q1) - L3*cos(q1)*sin(q2)) - sin(q1)*(L11*cos(q1) + L3*sin(q1)*sin(q2)), cos(q1)*(L7*sin(q1) - L11*sin(q1)) - sin(q1)*(L7*cos(q1) - L11*cos(q1));
                                     0,                                                                                 sin(q1),                                                                -sin(q1);
                                     0,                                                                                -cos(q1),                                                                 cos(q1);
                                     1,                                                                                       0,                                                                       0];
%current X
T3_W =[ - cos(q1)*cos(q2)*cos(q3) - cos(q1)*sin(q2)*sin(q3),  sin(q1), cos(q1)*cos(q3)*sin(q2) - cos(q1)*cos(q2)*sin(q3), sin(q1)*(L7 - L11) - L7*sin(q1) - L3*cos(q1)*sin(q2);
        - sin(q1)*sin(q2)*sin(q3) - cos(q2)*cos(q3)*sin(q1), -cos(q1), cos(q3)*sin(q1)*sin(q2) - cos(q2)*sin(q1)*sin(q3), L7*cos(q1) - cos(q1)*(L7 - L11) - L3*sin(q1)*sin(q2);
                          cos(q3)*sin(q2) - cos(q2)*sin(q3),        0,                 cos(q2)*cos(q3) + sin(q2)*sin(q3),                                      L1 - L3*cos(q2);
                                                          0,        0,                                                 0,                                                    1];

eulerA=R2EulerA(T3_W(1:3,1:3));                                                      
X=[T3_W(1:3,4);eulerA'];

Kp=diag([u(17);u(18);u(19)]);

x1d=u(2);
x2d=u(3);
x3d=u(4);
x4d=deg2rad(u(5));
x5d=deg2rad(u(6));
x6d=deg2rad(u(7));
Xd=[x1d;x2d;x3d;x4d;x5d;x6d];

x1dp=u(8);
x2dp=u(9);
x3dp=u(10);
x4dp=deg2rad(u(11));
x5dp=deg2rad(u(12));
x6dp=deg2rad(u(13));
Xdp=[x1dp;x2dp;x3dp;x4dp;x5dp;x6dp];

%Xrp
Xrp=Xdp-Kp*(X-Xd);

                                
Qrp=pinv(Jef)*Xrp;


end