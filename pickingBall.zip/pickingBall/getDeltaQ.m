function [DeltaQ] = getDeltaQ(u)

q1=u(1);
q2=u(2);
q3=u(3);
q1d=u(4);
q2d=u(5);
q3d=u(6);
Q=[q1;q2;q3];
Q=rad2deg(Q);
Qd=[q1d;q2d;q3d];
DeltaQ=Q-Qd;

end

