function [ phi_d,theta_d,psi_d ] = R2EulerA( R )

% TODO: Fill with the proper rotation Euler angles computation
%Attention:all the angles are within (-180��,180��],
%but theta_d should be within (-90��,90��]

phi_d=0;
theta_d=0;
psi_d=0;

d=(1-(R(3,1))^2)^(0.5);
theta_d=atan2(-R(3,1),d);
phi_d=atan2(R(2,1),R(1,1));
psi_d=atan2(R(3,2),R(3,3));

% theta_d=mod(theta_d/pi,2*pi);
% phi_d=mod(phi_d/pi*180,2*pi);
% psi_d=mod(psi_d/pi*180,2*pi);

end

