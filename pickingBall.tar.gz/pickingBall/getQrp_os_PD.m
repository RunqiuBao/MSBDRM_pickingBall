function [Qrp] = getQrp_os_PD(u)
q1=u(20);
q2=u(21);
q3=u(22);
% %Robot Parameters
% 
m1=u(26);
m2=u(27);
m3=u(28);
g=u(29);

L1=u(30);
L2=u(31);
L4=u(32);
L6=u(33);
L7=u(34);
L9=u(35);
L3=u(36);
L5=u(37);
L8=u(38);
L10=u(39);
L11=u(40);
L12=0.001*115.7;
L13=0;

%robot jacobian
Jef=[ cos(q1)*(L2 + L4 - L7 + L13) + L7*cos(q1) + L3*cos(q2)*sin(q1) + cos(q2)*sin(q1)*cos(q3 + atan(L12/(L5 - L12)))*(L12^2 + (L5 - L12)^2)^(1/2) - sin(q3 + atan(L12/(L5 - L12)))*sin(q1)*sin(q2)*(L12^2 + (L5 - L12)^2)^(1/2), cos(q1)*(L3*sin(q2) + sin(q2 + q3 + atan(L12/(L5 - L12)))*(L12^2 + (L5 - L12)^2)^(1/2)), sin(q2 + q3 + atan(L12/(L5 - L12)))*cos(q1)*(L12^2 + (L5 - L12)^2)^(1/2);
    sin(q1)*(L2 + L4 - L7 + L13) + L7*sin(q1) - L3*cos(q1)*cos(q2) - cos(q1)*cos(q2)*cos(q3 + atan(L12/(L5 - L12)))*(L12^2 + (L5 - L12)^2)^(1/2) + sin(q3 + atan(L12/(L5 - L12)))*cos(q1)*sin(q2)*(L12^2 + (L5 - L12)^2)^(1/2), sin(q1)*(L3*sin(q2) + sin(q2 + q3 + atan(L12/(L5 - L12)))*(L12^2 + (L5 - L12)^2)^(1/2)), sin(q2 + q3 + atan(L12/(L5 - L12)))*sin(q1)*(L12^2 + (L5 - L12)^2)^(1/2);
    0,    - cos(q2 + q3 + atan(L12/(L5 - L12)))*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) - L3*cos(q2),        -cos(q2 + q3 + atan(L12/(L5 - L12)))*(L12^2 + (L5 - L12)^2)^(1/2);
    0,                                                                                 sin(q1),                                                                  sin(q1);
    0,                                                                                -cos(q1),                                                                 -cos(q1);
    1,                                                                                       0,                                                                        0];
%current X
T3_0=[ cos(q2 + q3 + atan(L12/(L5 - L12)))*cos(q1), -sin(q2 + q3 + atan(L12/(L5 - L12)))*cos(q1),  sin(q1), sin(q1)*(L2 + L4 - L7 + L13) + L7*sin(q1) - L3*cos(q1)*cos(q2) - cos(q1)*cos(q2)*cos(q3 + atan(L12/(L5 - L12)))*(L12^2 + (L5 - L12)^2)^(1/2) + sin(q3 + atan(L12/(L5 - L12)))*cos(q1)*sin(q2)*(L12^2 + (L5 - L12)^2)^(1/2);
       cos(q2 + q3 + atan(L12/(L5 - L12)))*sin(q1), -sin(q2 + q3 + atan(L12/(L5 - L12)))*sin(q1), -cos(q1), sin(q3 + atan(L12/(L5 - L12)))*sin(q1)*sin(q2)*(L12^2 + (L5 - L12)^2)^(1/2) - L7*cos(q1) - L3*cos(q2)*sin(q1) - cos(q2)*sin(q1)*cos(q3 + atan(L12/(L5 - L12)))*(L12^2 + (L5 - L12)^2)^(1/2) - cos(q1)*(L2 + L4 - L7 + L13);
               sin(q2 + q3 + atan(L12/(L5 - L12))),          cos(q2 + q3 + atan(L12/(L5 - L12))),        0,                                                                                                                                         L1 - L3*sin(q2) - sin(q2 + q3 + atan(L12/(L5 - L12)))*(L12^2 + (L5 - L12)^2)^(1/2);
                                                 0,                                            0,        0,                                                                                                                                                                                                                          1];
[roll,pitch,yaw]=R2EulerA(T3_0(1:3,1:3));                                                      
X=[T3_0(1:3,4);roll;pitch;yaw];

Kp=diag([u(65);u(66);u(67);u(68);u(69);u(70)]);

x1d=u(2);
x2d=u(3);
x3d=u(4);
x4d=deg2rad(u(5));
x5d=deg2rad(u(6));
x6d=deg2rad(u(7));
Xd=[x1d;x2d;x3d;x4d;x5d;x6d];

x1dp=u(8);
x2dp=u(9);
x3dp=u(10);
x4dp=deg2rad(u(11));
x5dp=deg2rad(u(12));
x6dp=deg2rad(u(13));
Xdp=[x1dp;x2dp;x3dp;x4dp;x5dp;x6dp];

%Xrp
Xrp=Xdp-Kp*(X-Xd);
Jef_inv=pinv(Jef(1:3,:));                               
Qrp=Jef_inv*Xrp(1:3,1);


end