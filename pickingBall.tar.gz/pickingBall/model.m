%function [D_symbolic]=model(u)
syms q1 q2 q3 qp1 qp2 qp3 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 L13 real

D_symbolic(1,:)=[q1, L1, 0, sym(pi/2)];
D_symbolic(2,:)=[q2, L7, -L3, 0];
D_symbolic(3,:)=[q3+sym(atan(L12/(L5-L12))), L2+L4+L13-L7, -sqrt(L12^2+(L5-L12)^2), 0];

% DH of center of mass
D_symbolic(4,:)=[q1, L6, 0, 0];
D_symbolic(5,:)=[q2, L7, -L8, 0];
D_symbolic(6,:)=[q3, -L7+(L11+L9), -L10, 0];


%end