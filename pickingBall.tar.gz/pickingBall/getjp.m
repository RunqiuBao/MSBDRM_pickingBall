%getJp
syms q1 q2 q3 q1p q2p q3p L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 L13 real

T1_0=[ cos(q1), 0,  sin(q1),  0;
       sin(q1), 0, -cos(q1),  0;
             0, 1,        0, L1;
             0, 0,        0,  1];
% T1_0=T1_0*[1 0 0 0;0 0 1 0;0 -1 0 0;0 0 0 1]*[0 1 0 0;-1 0 0 0;0 0 1 0;0 0 0 1]*[0 1 0 0;-1 0 0 0;0 0 1 0;0 0 0 1];

T2_1=[                  cos(q2),                        -sin(q2),        0,                                                  -L3*cos(q2);
                        sin(q2),                         cos(q2),        0,                                                  -L3*sin(q2);
                              0,                               0,        1,                                                           L7;
                              0,                               0,        0,                                                            1];

T3_2=[ cos(q3 + atan(L12/(L5 - L12))), -sin(q3 + atan(L12/(L5 - L12))),        0, -cos(q3 + atan(L12/(L5 - L12)))*(L12^2 + (L5 - L12)^2)^(1/2);
       sin(q3 + atan(L12/(L5 - L12))),  cos(q3 + atan(L12/(L5 - L12))),        0, -sin(q3 + atan(L12/(L5 - L12)))*(L12^2 + (L5 - L12)^2)^(1/2);
                                    0,                               0,        1,                                           L2 + L4 - L7 + L13;
                                    0,                               0,        0,                                                            1];
                                
T3_0=T1_0*T2_1*T3_2;
T3_0=simplify(T3_0);

Tcm1_0=[ cos(q1), -sin(q1), 0,  0;
         sin(q1),  cos(q1), 0,  0;
               0,        0, 1, L6;
               0,        0, 0,  1];

Tcm2_1= [               cos(q2),                        -sin(q2),        0,                                                  -L8*cos(q2);
                        sin(q2),                         cos(q2),        0,                                                  -L8*sin(q2);
                              0,                               0,        1,                                                           L7;
                              0,                               0,        0,                                                            1];

Tcm3_2=[ cos(q3), -sin(q3), 0,   -L10*cos(q3);
         sin(q3),  cos(q3), 0,   -L10*sin(q3);
               0,        0, 1, -L7 + L9 + L11;
               0,        0, 0,             1];
           
Tcm2_0=T1_0*Tcm2_1;
Tcm2_0=simplify(Tcm2_0);
Tcm3_0=T1_0*T2_1*Tcm3_2;
Tcm3_0=simplify(Tcm3_0);                                
Jef=[ cos(q1)*(L2 + L4 - L7 + L13) + L7*cos(q1) + L3*cos(q2)*sin(q1) + cos(q2)*sin(q1)*cos(q3 + atan(L12/(L5 - L12)))*(L12^2 + (L5 - L12)^2)^(1/2) - sin(q3 + atan(L12/(L5 - L12)))*sin(q1)*sin(q2)*(L12^2 + (L5 - L12)^2)^(1/2), cos(q1)*(L3*sin(q2) + sin(q2 + q3 + atan(L12/(L5 - L12)))*(L12^2 + (L5 - L12)^2)^(1/2)), sin(q2 + q3 + atan(L12/(L5 - L12)))*cos(q1)*(L12^2 + (L5 - L12)^2)^(1/2);
 sin(q1)*(L2 + L4 - L7 + L13) + L7*sin(q1) - L3*cos(q1)*cos(q2) - cos(q1)*cos(q2)*cos(q3 + atan(L12/(L5 - L12)))*(L12^2 + (L5 - L12)^2)^(1/2) + sin(q3 + atan(L12/(L5 - L12)))*cos(q1)*sin(q2)*(L12^2 + (L5 - L12)^2)^(1/2), sin(q1)*(L3*sin(q2) + sin(q2 + q3 + atan(L12/(L5 - L12)))*(L12^2 + (L5 - L12)^2)^(1/2)), sin(q2 + q3 + atan(L12/(L5 - L12)))*sin(q1)*(L12^2 + (L5 - L12)^2)^(1/2);
                                                                                                                                                                                                                          0,    - cos(q2 + q3 + atan(L12/(L5 - L12)))*(L5^2 - 2*L5*L12 + 2*L12^2)^(1/2) - L3*cos(q2),        -cos(q2 + q3 + atan(L12/(L5 - L12)))*(L12^2 + (L5 - L12)^2)^(1/2);
                                                                                                                                                                                                                          0,                                                                                 sin(q1),                                                                  sin(q1);
                                                                                                                                                                                                                          0,                                                                                -cos(q1),                                                                 -cos(q1);
                                                                                                                                                                                                                          1,                                                                                       0,                                                                        0];
Jp=diff(Jef,q1)*q1p+diff(Jef,q2)*q2p+diff(Jef,q3)*q3p;
Jp=simplify(Jp);