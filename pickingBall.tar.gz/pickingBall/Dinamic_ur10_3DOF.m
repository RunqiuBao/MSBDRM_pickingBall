function [Qpp]=Dinamic_ur10_3DOF(u)

%Joint Position
q1=u(1);
q2=u(2);
q3=u(3);
q4=u(4);
q5=u(5);
q6=u(6);
%Joint Velocity
q1p=u(7);
q2p=u(8);
q3p=u(9);
q4p=u(10);
q5p=u(11);
q6p=u(12);
Tao=[u(13);u(14);u(15);u(16);u(17);u(18)];
%Gravity
g=9.81;
%kinematics parameters and mass
m1=7.1;
m2=12.7;
m3=4.27;
m4=2;
m5=2;
m6=0.365;
g=9.81;
%Viscous Friction Matrix
Beta(1,1)=0.1;
Beta(2,2)=0.1;
Beta(3,3)=0.1;
Beta(4,4)=0.1;
Beta(5,5)=0.1;
Beta(6,6)=0.1;
%Joint Position Vector
Q=[q1; q2; q3];

%Joint Velocity Vector
Qp=[q1p; q2p; q3p];

%Inertia Matrix
%Centripetal and Coriolis Matrix
%Gravitational Torques Vector
%[M,C,G]=getEoM();
%Complete the Inertia Matrix (symbolic form)
M =[ I133 + I211/2 + I222/2 + I311/2 + I322/2 - (I311*cos(2*q2 + 2*q3))/2 + (I322*cos(2*q2 + 2*q3))/2 + I312*sin(2*q2 + 2*q3) + (L3^2*m3)/2 + L7^2*m2 + (L8^2*m2)/2 + L9^2*m3 + (L10^2*m3)/2 + L11^2*m3 - (I211*cos(2*q2))/2 + (I222*cos(2*q2))/2 + I212*sin(2*q2) + 2*L9*L11*m3 + (L3^2*m3*cos(2*q2))/2 + (L8^2*m2*cos(2*q2))/2 + (L10^2*m3*cos(2*q2 + 2*q3))/2 + L3*L10*m3*cos(q3) + L3*L10*m3*cos(2*q2 + q3), I323*cos(q2 + q3) + I313*sin(q2 + q3) + I223*cos(q2) + I213*sin(q2) + L9*L10*m3*sin(q2 + q3) + L10*L11*m3*sin(q2 + q3) + L3*L9*m3*sin(q2) + L3*L11*m3*sin(q2) + L7*L8*m2*sin(q2), I323*cos(q2 + q3) + I313*sin(q2 + q3) + L9*L10*m3*sin(q2 + q3) + L10*L11*m3*sin(q2 + q3);
    I323*cos(q2 + q3) + I313*sin(q2 + q3) + I223*cos(q2) + I213*sin(q2) + L9*L10*m3*sin(q2 + q3) + L10*L11*m3*sin(q2 + q3) + L3*L9*m3*sin(q2) + L3*L11*m3*sin(q2) + L7*L8*m2*sin(q2),                                                                                                                m3*L3^2 + 2*m3*cos(q3)*L3*L10 + m2*L8^2 + m3*L10^2 + I233 + I333,                                                      m3*L10^2 + L3*m3*cos(q3)*L10 + I333;
    I323*cos(q2 + q3) + I313*sin(q2 + q3) + L9*L10*m3*sin(q2 + q3) + L10*L11*m3*sin(q2 + q3),                                                                                                                                              m3*L10^2 + L3*m3*cos(q3)*L10 + I333,                                                                          m3*L10^2 + I333];

%Complete Centripetal and Coriolis Matrix (symbolic form)
G =[                                                    0;
 - g*m3*(L10*cos(q2 + q3) + L3*cos(q2)) - L8*g*m2*cos(q2);
                                   -L10*g*m3*cos(q2 + q3)];
 
 

%Complete Gravitational Torques Vector (symbolic form)
C =[ I212*q2p*cos(2*q2) + (I211*q2p*sin(2*q2))/2 - (I222*q2p*sin(2*q2))/2 + I312*q2p*cos(2*q2 + 2*q3) + I312*q3p*cos(2*q2 + 2*q3) + (I311*q2p*sin(2*q2 + 2*q3))/2 + (I311*q3p*sin(2*q2 + 2*q3))/2 - (I322*q2p*sin(2*q2 + 2*q3))/2 - (I322*q3p*sin(2*q2 + 2*q3))/2 - (L3^2*m3*q2p*sin(2*q2))/2 - (L8^2*m2*q2p*sin(2*q2))/2 - (L10^2*m3*q2p*sin(2*q2 + 2*q3))/2 - (L10^2*m3*q3p*sin(2*q2 + 2*q3))/2 - (L3*L10*m3*q3p*sin(q3))/2 - L3*L10*m3*q2p*sin(2*q2 + q3) - (L3*L10*m3*q3p*sin(2*q2 + q3))/2, I212*q1p*cos(2*q2) + (I211*q1p*sin(2*q2))/2 - (I222*q1p*sin(2*q2))/2 + I312*q1p*cos(2*q2 + 2*q3) + (I311*q1p*sin(2*q2 + 2*q3))/2 - (I322*q1p*sin(2*q2 + 2*q3))/2 + I313*q2p*cos(q2 + q3) + I313*q3p*cos(q2 + q3) - I323*q2p*sin(q2 + q3) - I323*q3p*sin(q2 + q3) + I213*q2p*cos(q2) - I223*q2p*sin(q2) - (L3^2*m3*q1p*sin(2*q2))/2 - (L8^2*m2*q1p*sin(2*q2))/2 - (L10^2*m3*q1p*sin(2*q2 + 2*q3))/2 + L9*L10*m3*q2p*cos(q2 + q3) + L9*L10*m3*q3p*cos(q2 + q3) + L10*L11*m3*q2p*cos(q2 + q3) + L10*L11*m3*q3p*cos(q2 + q3) + L3*L9*m3*q2p*cos(q2) + L3*L11*m3*q2p*cos(q2) + L7*L8*m2*q2p*cos(q2) - L3*L10*m3*q1p*sin(2*q2 + q3), I312*q1p*cos(2*q2 + 2*q3) + (I311*q1p*sin(2*q2 + 2*q3))/2 - (I322*q1p*sin(2*q2 + 2*q3))/2 + I313*q2p*cos(q2 + q3) + I313*q3p*cos(q2 + q3) - I323*q2p*sin(q2 + q3) - I323*q3p*sin(q2 + q3) - (L10^2*m3*q1p*sin(2*q2 + 2*q3))/2 + L9*L10*m3*q2p*cos(q2 + q3) + L9*L10*m3*q3p*cos(q2 + q3) + L10*L11*m3*q2p*cos(q2 + q3) + L10*L11*m3*q3p*cos(q2 + q3) - (L3*L10*m3*q1p*sin(q3))/2 - (L3*L10*m3*q1p*sin(2*q2 + q3))/2;
                                                                                                                                                                                                                                                    (q1p*(m3*sin(2*q2)*L3^2 + 2*m3*sin(2*q2 + q3)*L3*L10 + m2*sin(2*q2)*L8^2 + m3*sin(2*q2 + 2*q3)*L10^2 - 2*I312*cos(2*q2 + 2*q3) - I311*sin(2*q2 + 2*q3) + I322*sin(2*q2 + 2*q3) - 2*I212*cos(2*q2) - I211*sin(2*q2) + I222*sin(2*q2)))/2,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        -L3*L10*m3*q3p*sin(q3),                                                                                                                                                                                                                                                                                                                                                                                     -L3*L10*m3*sin(q3)*(q2p + q3p);
                                                                                                                                                                                                                                                                                                                               (q1p*(I322*sin(2*q2 + 2*q3) - I311*sin(2*q2 + 2*q3) - 2*I312*cos(2*q2 + 2*q3) + L10^2*m3*sin(2*q2 + 2*q3) + L3*L10*m3*sin(q3) + L3*L10*m3*sin(2*q2 + q3)))/2,                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         L3*L10*m3*q2p*sin(q3),                                                                                                                                                                                                                                                                                                                                                                                                                  0];
 
Tao=[u(47);u(48);u(49)];


Qpp=(M)\(Tao-C*Qp-G-Beta*Qp);
Qpp=double(Qpp);
