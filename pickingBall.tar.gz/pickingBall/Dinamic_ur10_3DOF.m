function [Qpp]=Dinamic_ur10_3DOF(u)

%Joint Position
q1=u(1);
q2=u(2);
q3=u(3);
%Joint Velocity
q1p=u(4);
q2p=u(5);
q3p=u(6);
Tao=[u(7);u(8);u(9)];

%Viscous Friction Matrix
Beta(1,1)=0.1;
Beta(2,2)=0.1;
Beta(3,3)=0.1;
%Joint Position Vector
Q=[q1; q2; q3];

%Joint Velocity Vector
Qp=[q1p; q2p; q3p];

%Inertia Matrix
%Centripetal and Coriolis Matrix
%Gravitational Torques Vector
%Complete the Inertia Matrix
M =[ (21058499*cos(2*q2 + q3))/100000000 + (1877129*cos(2*q2))/8000000 + sin(2*q2)/50 + (11812969*cos(2*q2 + 2*q3))/200000000 + sin(2*q2 + 2*q3)/50 + (21058499*cos(q3))/100000000 + 43980597/100000000, cos(q2 + q3)/50 + (20311*sin(q2 + q3))/500000 + cos(q2)/50 + (51361*sin(q2))/500000,     cos(q2 + q3)/50 + (20311*sin(q2 + q3))/500000;
                                                                                                                cos(q2 + q3)/50 + (20311*sin(q2 + q3))/500000 + cos(q2)/50 + (51361*sin(q2))/500000,                                     (21058499*cos(q3))/50000000 + 33370597/50000000, (21058499*cos(q3))/100000000 + 15812969/100000000;
                                                                                                                                                      cos(q2 + q3)/50 + (20311*sin(q2 + q3))/500000,                                   (21058499*cos(q3))/100000000 + 15812969/100000000,                                15812969/100000000];

%Complete Centripetal and Coriolis Matrix
G =[                                                        0;
 - (3371697*cos(q2 + q3))/1000000 - (9016371*cos(q2))/1000000;
                              -(3371697*cos(q2 + q3))/1000000];


%Complete Gravitational Torques Vector (symbolic form)
C =[ (q2p*cos(2*q2))/50 - (1877129*q2p*sin(2*q2))/8000000 + (q2p*cos(2*q2 + 2*q3))/50 + (q3p*cos(2*q2 + 2*q3))/50 - (11812969*q2p*sin(2*q2 + 2*q3))/200000000 - (11812969*q3p*sin(2*q2 + 2*q3))/200000000 - (21058499*q3p*sin(q3))/200000000 - (21058499*q2p*sin(2*q2 + q3))/100000000 - (21058499*q3p*sin(2*q2 + q3))/200000000, (q1p*cos(2*q2))/50 - (1877129*q1p*sin(2*q2))/8000000 + (q1p*cos(2*q2 + 2*q3))/50 - (11812969*q1p*sin(2*q2 + 2*q3))/200000000 + (20311*q2p*cos(q2 + q3))/500000 + (20311*q3p*cos(q2 + q3))/500000 - (q2p*sin(q2 + q3))/50 - (q3p*sin(q2 + q3))/50 + (51361*q2p*cos(q2))/500000 - (q2p*sin(q2))/50 - (21058499*q1p*sin(2*q2 + q3))/100000000, (q1p*cos(2*q2 + 2*q3))/50 - (11812969*q1p*sin(2*q2 + 2*q3))/200000000 + (20311*q2p*cos(q2 + q3))/500000 + (20311*q3p*cos(q2 + q3))/500000 - (q2p*sin(q2 + q3))/50 - (q3p*sin(q2 + q3))/50 - (21058499*q1p*sin(q3))/200000000 - (21058499*q1p*sin(2*q2 + q3))/200000000;
    (q1p*((21058499*sin(2*q2 + q3))/50000000 - cos(2*q2)/25 + (1877129*sin(2*q2))/4000000 - cos(2*q2 + 2*q3)/25 + (11812969*sin(2*q2 + 2*q3))/100000000))/2,                                                                                                                                                                                                                                                                                                          -(21058499*q3p*sin(q3))/100000000,                                                                                                                                                                                                                              -(21058499*sin(q3)*(q2p + q3p))/100000000;
    (q1p*((21058499*sin(2*q2 + q3))/100000000 - cos(2*q2 + 2*q3)/25 + (11812969*sin(2*q2 + 2*q3))/100000000 + (21058499*sin(q3))/100000000))/2,                                                                                                                                                                                                                                                                                                           (21058499*q2p*sin(q3))/100000000,                                                                                                                                                                                                                                                                      0];

Qpp=(M)\(Tao-C*Qp-G-Beta*Qp);
Qpp=double(Qpp);
