%%

syms g z0 m1 m2 m3 m4 m5 m6 L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 L13 q1 q2 q3 q4 q5 q6 d1 d2 d3 d4 d5 d6 dcm1 dcm2 dcm3 dcm4 dcm5 dcm6 a1 a2 a3 a4 a5 a6 acm1 acm2 acm3 acm4 acm5 t1 real
syms I111 I112 I113 I122 I123 I133 real
syms I211 I212 I213 I222 I223 I233 real
syms I311 I312 I313 I322 I323 I333 real
syms I411 I412 I413 I422 I423 I433 real
syms I511 I512 I513 I522 I523 I533 real
syms I611 I612 I613 I622 I623 I633 real
syms q1p q2p q3p q4p q5p q6p real
syms q1pp q2pp q3pp q4pp q5pp q6pp q1rp q2rp q3rp q4rp q5rp q6rp q1rpp q2rpp q3rpp q4rpp q5rpp q6rpp qrp qrpp real
% 

%% Reconstruct Inertia matrices
I1=[I111 I112 I113;
    I112 I122 I123;
    I113 I123 I133];

I2=[I211 I212 I213;
    I212 I222 I223;
    I213 I223 I233];

I3=[I311 I312 I313;
    I312 I322 I323;
    I313 I323 I333];

I4=[I411 I412 I413;
    I412 I422 I423;
    I413 I423 I433];

I5=[I511 I512 I513;
    I512 I522 I523;
    I513 I523 I533];

I6=[I611 I612 I613;
    I612 I622 I623;
    I613 I623 I633];
%% Jacobian
Jcm1=[ -acm1*sin(q1 - t1), 0, 0, 0, 0, 0;
    acm1*cos(q1 - t1), 0, 0, 0, 0, 0;
    0, 0, 0, 0, 0, 0;
    0, 0, 0, 0, 0, 0;
    0, 0, 0, 0, 0, 0;
    1, 0, 0, 0, 0, 0];

Jcm2=[ dcm2*cos(q1) - acm2*cos(q2)*sin(q1), -acm2*cos(q1)*sin(q2), 0, 0, 0, 0;
    dcm2*sin(q1) + acm2*cos(q1)*cos(q2), -acm2*sin(q1)*sin(q2), 0, 0, 0, 0;
    0,          acm2*cos(q2), 0, 0, 0, 0;
    0,               sin(q1), 0, 0, 0, 0;
    0,              -cos(q1), 0, 0, 0, 0;
    1,                     0, 0, 0, 0, 0];

Jcm3=[ dcm3*cos(q1) - a2*cos(q2)*sin(q1) - acm3*cos(q2)*cos(q3)*sin(q1) + acm3*sin(q1)*sin(q2)*sin(q3), -cos(q1)*(acm3*sin(q2 + q3) + a2*sin(q2)), -acm3*sin(q2 + q3)*cos(q1), 0, 0, 0;
    dcm3*sin(q1) + a2*cos(q1)*cos(q2) + acm3*cos(q1)*cos(q2)*cos(q3) - acm3*cos(q1)*sin(q2)*sin(q3), -sin(q1)*(acm3*sin(q2 + q3) + a2*sin(q2)), -acm3*sin(q2 + q3)*sin(q1), 0, 0, 0;
    0,            acm3*cos(q2 + q3) + a2*cos(q2),          acm3*cos(q2 + q3), 0, 0, 0;
    0,                                   sin(q1),                    sin(q1), 0, 0, 0;
    0,                                  -cos(q1),                   -cos(q1), 0, 0, 0;
    1,                                         0,                          0, 0, 0, 0];
Jcm4=[ dcm4*cos(q1) - a2*cos(q2)*sin(q1) - a3*cos(q2)*cos(q3)*sin(q1) + a3*sin(q1)*sin(q2)*sin(q3) + acm4*cos(q2)*cos(q3)*sin(q1)*sin(q4) + acm4*cos(q2)*cos(q4)*sin(q1)*sin(q3) + acm4*cos(q3)*cos(q4)*sin(q1)*sin(q2) - acm4*sin(q1)*sin(q2)*sin(q3)*sin(q4), -cos(q1)*(a3*sin(q2 + q3) + a2*sin(q2) + acm4*cos(q2 + q3 + q4)), - (a3*sin(q2 - q1 + q3))/2 - (acm4*cos(q1 + q2 + q3 + q4))/2 - (acm4*cos(q2 - q1 + q3 + q4))/2 - (a3*sin(q1 + q2 + q3))/2, -(acm4*(cos(q1 + q2 + q3 + q4) + cos(q2 - q1 + q3 + q4)))/2, 0, 0;
    dcm4*sin(q1) + a2*cos(q1)*cos(q2) + a3*cos(q1)*cos(q2)*cos(q3) - a3*cos(q1)*sin(q2)*sin(q3) - acm4*cos(q1)*cos(q2)*cos(q3)*sin(q4) - acm4*cos(q1)*cos(q2)*cos(q4)*sin(q3) - acm4*cos(q1)*cos(q3)*cos(q4)*sin(q2) + acm4*cos(q1)*sin(q2)*sin(q3)*sin(q4), -sin(q1)*(a3*sin(q2 + q3) + a2*sin(q2) + acm4*cos(q2 + q3 + q4)),   (acm4*sin(q2 - q1 + q3 + q4))/2 - (acm4*sin(q1 + q2 + q3 + q4))/2 - (a3*cos(q2 - q1 + q3))/2 + (a3*cos(q1 + q2 + q3))/2, -(acm4*(sin(q1 + q2 + q3 + q4) - sin(q2 - q1 + q3 + q4)))/2, 0, 0;
    0,            a3*cos(q2 + q3) + a2*cos(q2) - acm4*sin(q2 + q3 + q4),                                                                                  a3*cos(q2 + q3) - acm4*sin(q2 + q3 + q4),                                     -acm4*sin(q2 + q3 + q4), 0, 0;
    0,                                                          sin(q1),                                                                                                                   sin(q1),                                                     sin(q1), 0, 0;
    0,                                                         -cos(q1),                                                                                                                  -cos(q1),                                                    -cos(q1), 0, 0;
    1,                                                                0,                                                                                                                         0,                                                           0, 0, 0];
Jcm5=[ d4*cos(q1) - acm5*cos(q1)*cos(q5) - a2*cos(q2)*sin(q1) - a3*cos(q2)*cos(q3)*sin(q1) + a3*sin(q1)*sin(q2)*sin(q3) - dcm5*cos(q2)*cos(q3)*sin(q1)*sin(q4) - dcm5*cos(q2)*cos(q4)*sin(q1)*sin(q3) - dcm5*cos(q3)*cos(q4)*sin(q1)*sin(q2) + dcm5*sin(q1)*sin(q2)*sin(q3)*sin(q4) - acm5*cos(q2)*cos(q3)*cos(q4)*sin(q1)*sin(q5) + acm5*cos(q2)*sin(q1)*sin(q3)*sin(q4)*sin(q5) + acm5*cos(q3)*sin(q1)*sin(q2)*sin(q4)*sin(q5) + acm5*cos(q4)*sin(q1)*sin(q2)*sin(q3)*sin(q5), -cos(q1)*(a3*sin(q2 + q3) - (acm5*cos(q2 + q3 + q4 + q5))/2 + a2*sin(q2) + (acm5*cos(q2 + q3 + q4 - q5))/2 - dcm5*cos(q2 + q3 + q4)), cos(q1)*((acm5*cos(q2 + q3 + q4 + q5))/2 - a3*sin(q2 + q3) - (acm5*cos(q2 + q3 + q4 - q5))/2 + dcm5*cos(q2 + q3 + q4)), cos(q1)*((acm5*cos(q2 + q3 + q4 + q5))/2 - (acm5*cos(q2 + q3 + q4 - q5))/2 + dcm5*cos(q2 + q3 + q4)), acm5*sin(q1)*sin(q5) - acm5*cos(q1)*cos(q2)*cos(q5)*sin(q3)*sin(q4) - acm5*cos(q1)*cos(q3)*cos(q5)*sin(q2)*sin(q4) - acm5*cos(q1)*cos(q4)*cos(q5)*sin(q2)*sin(q3) + acm5*cos(q1)*cos(q2)*cos(q3)*cos(q4)*cos(q5), 0;
    d4*sin(q1) + a2*cos(q1)*cos(q2) - acm5*cos(q5)*sin(q1) + a3*cos(q1)*cos(q2)*cos(q3) - a3*cos(q1)*sin(q2)*sin(q3) + dcm5*cos(q1)*cos(q2)*cos(q3)*sin(q4) + dcm5*cos(q1)*cos(q2)*cos(q4)*sin(q3) + dcm5*cos(q1)*cos(q3)*cos(q4)*sin(q2) - dcm5*cos(q1)*sin(q2)*sin(q3)*sin(q4) - acm5*cos(q1)*cos(q2)*sin(q3)*sin(q4)*sin(q5) - acm5*cos(q1)*cos(q3)*sin(q2)*sin(q4)*sin(q5) - acm5*cos(q1)*cos(q4)*sin(q2)*sin(q3)*sin(q5) + acm5*cos(q1)*cos(q2)*cos(q3)*cos(q4)*sin(q5), -sin(q1)*(a3*sin(q2 + q3) - (acm5*cos(q2 + q3 + q4 + q5))/2 + a2*sin(q2) + (acm5*cos(q2 + q3 + q4 - q5))/2 - dcm5*cos(q2 + q3 + q4)), sin(q1)*((acm5*cos(q2 + q3 + q4 + q5))/2 - a3*sin(q2 + q3) - (acm5*cos(q2 + q3 + q4 - q5))/2 + dcm5*cos(q2 + q3 + q4)), sin(q1)*((acm5*cos(q2 + q3 + q4 + q5))/2 - (acm5*cos(q2 + q3 + q4 - q5))/2 + dcm5*cos(q2 + q3 + q4)), acm5*cos(q2)*cos(q3)*cos(q4)*cos(q5)*sin(q1) - acm5*cos(q2)*cos(q5)*sin(q1)*sin(q3)*sin(q4) - acm5*cos(q3)*cos(q5)*sin(q1)*sin(q2)*sin(q4) - acm5*cos(q4)*cos(q5)*sin(q1)*sin(q2)*sin(q3) - acm5*cos(q1)*sin(q5), 0;
    0,            (acm5*sin(q2 + q3 + q4 + q5))/2 + a3*cos(q2 + q3) + a2*cos(q2) - (acm5*sin(q2 + q3 + q4 - q5))/2 + dcm5*sin(q2 + q3 + q4),           (acm5*sin(q2 + q3 + q4 + q5))/2 + a3*cos(q2 + q3) - (acm5*sin(q2 + q3 + q4 - q5))/2 + dcm5*sin(q2 + q3 + q4),           (acm5*sin(q2 + q3 + q4 + q5))/2 - (acm5*sin(q2 + q3 + q4 - q5))/2 + dcm5*sin(q2 + q3 + q4),                                                                                                                                                       (acm5*(sin(q2 + q3 + q4 + q5) + sin(q2 + q3 + q4 - q5)))/2, 0;
    0,                                                                                                                              sin(q1),                                                                                                                sin(q1),                                                                                              sin(q1),                                                                                                                                                              sin(q1 + q2 + q3 + q4)/2 + sin(q2 - q1 + q3 + q4)/2, 0;
    0,                                                                                                                             -cos(q1),                                                                                                               -cos(q1),                                                                                             -cos(q1),                                                                                                                                                              cos(q2 - q1 + q3 + q4)/2 - cos(q1 + q2 + q3 + q4)/2, 0;
    1,                                                                                                                                    0,                                                                                                                      0,                                                                                                    0,                                                                                                                                                                                               -cos(q2 + q3 + q4), 0];
Jcm6=[ d4*cos(q1) + dcm6*cos(q1)*cos(q5) - a2*cos(q2)*sin(q1) - a3*cos(q2)*cos(q3)*sin(q1) + a3*sin(q1)*sin(q2)*sin(q3) - d5*cos(q2)*cos(q3)*sin(q1)*sin(q4) - d5*cos(q2)*cos(q4)*sin(q1)*sin(q3) - d5*cos(q3)*cos(q4)*sin(q1)*sin(q2) + d5*sin(q1)*sin(q2)*sin(q3)*sin(q4) + dcm6*cos(q2)*cos(q3)*cos(q4)*sin(q1)*sin(q5) - dcm6*cos(q2)*sin(q1)*sin(q3)*sin(q4)*sin(q5) - dcm6*cos(q3)*sin(q1)*sin(q2)*sin(q4)*sin(q5) - dcm6*cos(q4)*sin(q1)*sin(q2)*sin(q3)*sin(q5), -cos(q1)*((dcm6*cos(q2 + q3 + q4 + q5))/2 + a3*sin(q2 + q3) + a2*sin(q2) - (dcm6*cos(q2 + q3 + q4 - q5))/2 - d5*cos(q2 + q3 + q4)), -cos(q1)*((dcm6*cos(q2 + q3 + q4 + q5))/2 + a3*sin(q2 + q3) - (dcm6*cos(q2 + q3 + q4 - q5))/2 - d5*cos(q2 + q3 + q4)), cos(q1)*((dcm6*cos(q2 + q3 + q4 - q5))/2 - (dcm6*cos(q2 + q3 + q4 + q5))/2 + d5*cos(q2 + q3 + q4)), dcm6*cos(q1)*cos(q2)*cos(q5)*sin(q3)*sin(q4) - dcm6*sin(q1)*sin(q5) + dcm6*cos(q1)*cos(q3)*cos(q5)*sin(q2)*sin(q4) + dcm6*cos(q1)*cos(q4)*cos(q5)*sin(q2)*sin(q3) - dcm6*cos(q1)*cos(q2)*cos(q3)*cos(q4)*cos(q5),                                                                                                                                                                                       0;
    d4*sin(q1) + a2*cos(q1)*cos(q2) + dcm6*cos(q5)*sin(q1) + a3*cos(q1)*cos(q2)*cos(q3) - a3*cos(q1)*sin(q2)*sin(q3) + d5*cos(q1)*cos(q2)*cos(q3)*sin(q4) + d5*cos(q1)*cos(q2)*cos(q4)*sin(q3) + d5*cos(q1)*cos(q3)*cos(q4)*sin(q2) - d5*cos(q1)*sin(q2)*sin(q3)*sin(q4) + dcm6*cos(q1)*cos(q2)*sin(q3)*sin(q4)*sin(q5) + dcm6*cos(q1)*cos(q3)*sin(q2)*sin(q4)*sin(q5) + dcm6*cos(q1)*cos(q4)*sin(q2)*sin(q3)*sin(q5) - dcm6*cos(q1)*cos(q2)*cos(q3)*cos(q4)*sin(q5), -sin(q1)*((dcm6*cos(q2 + q3 + q4 + q5))/2 + a3*sin(q2 + q3) + a2*sin(q2) - (dcm6*cos(q2 + q3 + q4 - q5))/2 - d5*cos(q2 + q3 + q4)), -sin(q1)*((dcm6*cos(q2 + q3 + q4 + q5))/2 + a3*sin(q2 + q3) - (dcm6*cos(q2 + q3 + q4 - q5))/2 - d5*cos(q2 + q3 + q4)), sin(q1)*((dcm6*cos(q2 + q3 + q4 - q5))/2 - (dcm6*cos(q2 + q3 + q4 + q5))/2 + d5*cos(q2 + q3 + q4)), dcm6*cos(q1)*sin(q5) + dcm6*cos(q2)*cos(q5)*sin(q1)*sin(q3)*sin(q4) + dcm6*cos(q3)*cos(q5)*sin(q1)*sin(q2)*sin(q4) + dcm6*cos(q4)*cos(q5)*sin(q1)*sin(q2)*sin(q3) - dcm6*cos(q2)*cos(q3)*cos(q4)*cos(q5)*sin(q1),                                                                                                                                                                                       0;
    0,            a3*cos(q2 + q3) - (dcm6*sin(q2 + q3 + q4 + q5))/2 + a2*cos(q2) + (dcm6*sin(q2 + q3 + q4 - q5))/2 + d5*sin(q2 + q3 + q4),            a3*cos(q2 + q3) - (dcm6*sin(q2 + q3 + q4 + q5))/2 + (dcm6*sin(q2 + q3 + q4 - q5))/2 + d5*sin(q2 + q3 + q4),           (dcm6*sin(q2 + q3 + q4 - q5))/2 - (dcm6*sin(q2 + q3 + q4 + q5))/2 + d5*sin(q2 + q3 + q4),                                                                                                                                                      -(dcm6*(sin(q2 + q3 + q4 + q5) + sin(q2 + q3 + q4 - q5)))/2,                                                                                                                                                                                       0;
    0,                                                                                                                            sin(q1),                                                                                                               sin(q1),                                                                                            sin(q1),                                                                                                                                                              sin(q1 + q2 + q3 + q4)/2 + sin(q2 - q1 + q3 + q4)/2, cos(q5)*sin(q1) - cos(q1)*cos(q2)*cos(q3)*cos(q4)*sin(q5) + cos(q1)*cos(q2)*sin(q3)*sin(q4)*sin(q5) + cos(q1)*cos(q3)*sin(q2)*sin(q4)*sin(q5) + cos(q1)*cos(q4)*sin(q2)*sin(q3)*sin(q5);
    0,                                                                                                                           -cos(q1),                                                                                                              -cos(q1),                                                                                           -cos(q1),                                                                                                                                                              cos(q2 - q1 + q3 + q4)/2 - cos(q1 + q2 + q3 + q4)/2, cos(q2)*sin(q1)*sin(q3)*sin(q4)*sin(q5) - cos(q2)*cos(q3)*cos(q4)*sin(q1)*sin(q5) - cos(q1)*cos(q5) + cos(q3)*sin(q1)*sin(q2)*sin(q4)*sin(q5) + cos(q4)*sin(q1)*sin(q2)*sin(q3)*sin(q5);
    1,                                                                                                                                  0,                                                                                                                     0,                                                                                                  0,                                                                                                                                                                                               -cos(q2 + q3 + q4),                                                                                                                                     cos(q2 + q3 + q4 + q5)/2 - cos(q2 + q3 + q4 - q5)/2];

Hcm1_0=[ cos(q1 - t1), -sin(q1 - t1), 0, acm1*cos(q1 - t1);
    sin(q1 - t1),  cos(q1 - t1), 0, acm1*sin(q1 - t1);
    0,             0, 1,              dcm1;
    0,             0, 0,                 1];

Hcm2_0=[ cos(q1)*cos(q2), -cos(q1)*sin(q2),  sin(q1), dcm2*sin(q1) + acm2*cos(q1)*cos(q2);
    cos(q2)*sin(q1), -sin(q1)*sin(q2), -cos(q1), acm2*cos(q2)*sin(q1) - dcm2*cos(q1);
    sin(q2),          cos(q2),        0,                   d1 + acm2*sin(q2);
    0,                0,        0,                                   1];


Hcm3_0=[ cos(q2 + q3)*cos(q1), -sin(q2 + q3)*cos(q1),  sin(q1), dcm3*sin(q1) + a2*cos(q1)*cos(q2) + acm3*cos(q1)*cos(q2)*cos(q3) - acm3*cos(q1)*sin(q2)*sin(q3);
    cos(q2 + q3)*sin(q1), -sin(q2 + q3)*sin(q1), -cos(q1), a2*cos(q2)*sin(q1) - dcm3*cos(q1) + acm3*cos(q2)*cos(q3)*sin(q1) - acm3*sin(q1)*sin(q2)*sin(q3);
    sin(q2 + q3),          cos(q2 + q3),        0,                                                             d1 + acm3*sin(q2 + q3) + a2*sin(q2);
    0,                     0,        0,                                                                                               1];

Hcm4_0=[ -sin(q2 + q3 + q4)*cos(q1), -cos(q2 + q3 + q4)*cos(q1),  sin(q1), cos(q1)*(a3*cos(q2 + q3) + a2*cos(q2)) + dcm4*sin(q1) - acm4*cos(q2 + q3)*cos(q1)*sin(q4) - acm4*sin(q2 + q3)*cos(q1)*cos(q4);
    -sin(q2 + q3 + q4)*sin(q1), -cos(q2 + q3 + q4)*sin(q1), -cos(q1), sin(q1)*(a3*cos(q2 + q3) + a2*cos(q2)) - dcm4*cos(q1) - acm4*cos(q2 + q3)*sin(q1)*sin(q4) - acm4*sin(q2 + q3)*cos(q4)*sin(q1);
    cos(q2 + q3 + q4),         -sin(q2 + q3 + q4),        0,                                                                    d1 + a3*sin(q2 + q3) + a2*sin(q2) + acm4*cos(q2 + q3 + q4);
    0,                          0,        0,                                                                                                                             1];

Hcm5_0=[ cos(q2 + q3 + q4)*cos(q1)*sin(q5) - cos(q5)*sin(q1), sin(q1)*sin(q5) + cos(q2 + q3 + q4)*cos(q1)*cos(q5), sin(q2 + q3 + q4)*cos(q1), cos(q1)*(a3*cos(q2 + q3) + a2*cos(q2)) + d4*sin(q1) - acm5*cos(q5)*sin(q1) + dcm5*sin(q2 + q3 + q4)*cos(q1) + acm5*cos(q2 + q3 + q4)*cos(q1)*sin(q5);
    cos(q1)*cos(q5) + cos(q2 + q3 + q4)*sin(q1)*sin(q5), cos(q2 + q3 + q4)*cos(q5)*sin(q1) - cos(q1)*sin(q5), sin(q2 + q3 + q4)*sin(q1), sin(q1)*(a3*cos(q2 + q3) + a2*cos(q2)) - d4*cos(q1) + acm5*cos(q1)*cos(q5) + dcm5*sin(q2 + q3 + q4)*sin(q1) + acm5*cos(q2 + q3 + q4)*sin(q1)*sin(q5);
    sin(q2 + q3 + q4)*sin(q5),                           sin(q2 + q3 + q4)*cos(q5),        -cos(q2 + q3 + q4),                                                          d1 + a3*sin(q2 + q3) + a2*sin(q2) - dcm5*cos(q2 + q3 + q4) + acm5*sin(q2 + q3 + q4)*sin(q5);
    0,                                                   0,                         0,                                                                                                                                                    1];

Hcm6_0=[ - sin(q6)*(sin(q1)*sin(q5) + cos(q2 + q3 + q4)*cos(q1)*cos(q5)) - sin(q2 + q3 + q4)*cos(q1)*cos(q6), sin(q2 + q3 + q4)*cos(q1)*sin(q6) - cos(q6)*(sin(q1)*sin(q5) + cos(q2 + q3 + q4)*cos(q1)*cos(q5)),   cos(q5)*sin(q1) - cos(q2 + q3 + q4)*cos(q1)*sin(q5), dcm6*(cos(q5)*sin(q1) - cos(q2 + q3 + q4)*cos(q1)*sin(q5)) + cos(q1)*(a3*cos(q2 + q3) + a2*cos(q2)) + d4*sin(q1) + d5*sin(q2 + q3 + q4)*cos(q1);
    sin(q6)*(cos(q1)*sin(q5) - cos(q2 + q3 + q4)*cos(q5)*sin(q1)) - sin(q2 + q3 + q4)*cos(q6)*sin(q1), cos(q6)*(cos(q1)*sin(q5) - cos(q2 + q3 + q4)*cos(q5)*sin(q1)) + sin(q2 + q3 + q4)*sin(q1)*sin(q6), - cos(q1)*cos(q5) - cos(q2 + q3 + q4)*sin(q1)*sin(q5), sin(q1)*(a3*cos(q2 + q3) + a2*cos(q2)) - d4*cos(q1) - dcm6*(cos(q1)*cos(q5) + cos(q2 + q3 + q4)*sin(q1)*sin(q5)) + d5*sin(q2 + q3 + q4)*sin(q1);
    cos(q2 + q3 + q4)*cos(q6) - sin(q2 + q3 + q4)*cos(q5)*sin(q6),                                   - cos(q2 + q3 + q4)*sin(q6) - sin(q2 + q3 + q4)*cos(q5)*cos(q6),                            -sin(q2 + q3 + q4)*sin(q5),                                                       d1 + a3*sin(q2 + q3) + a2*sin(q2) - d5*cos(q2 + q3 + q4) - dcm6*sin(q2 + q3 + q4)*sin(q5);
    0,                                                                                                 0,                                                     0,                                                                                                                                               1];


%% Get Rotation and Translation from HT.
Rcm1_0=Hcm1_0(1:3,1:3);
Rcm2_0=Hcm2_0(1:3,1:3);
Rcm3_0=Hcm3_0(1:3,1:3);
Rcm4_0=Hcm4_0(1:3,1:3);
Rcm5_0=Hcm5_0(1:3,1:3);
Rcm6_0=Hcm6_0(1:3,1:3);

tcm1_0=Hcm1_0(1:3,4);
tcm2_0=Hcm2_0(1:3,4);
tcm3_0=Hcm3_0(1:3,4);
tcm4_0=Hcm4_0(1:3,4);
tcm5_0=Hcm5_0(1:3,4);
tcm6_0=Hcm6_0(1:3,4);

%% Compute M
M=m1*Jcm1(1:3,:)'*Jcm1(1:3,:)+...
    m2*Jcm2(1:3,:)'*Jcm2(1:3,:)+...
    m3*Jcm3(1:3,:)'*Jcm3(1:3,:)+...
    m4*Jcm4(1:3,:)'*Jcm4(1:3,:)+...
    m5*Jcm5(1:3,:)'*Jcm5(1:3,:)+...
    m6*Jcm6(1:3,:)'*Jcm6(1:3,:)+...
    Jcm1(4:6,:)'*Rcm1_0*I1*Rcm1_0'*Jcm1(4:6,:)+...
    Jcm2(4:6,:)'*Rcm2_0*I2*Rcm2_0'*Jcm2(4:6,:)+...
    Jcm3(4:6,:)'*Rcm3_0*I3*Rcm3_0'*Jcm3(4:6,:)+...
    Jcm4(4:6,:)'*Rcm4_0*I4*Rcm4_0'*Jcm4(4:6,:)+...
    Jcm5(4:6,:)'*Rcm5_0*I5*Rcm5_0'*Jcm5(4:6,:)+...
    Jcm6(4:6,:)'*Rcm6_0*I6*Rcm6_0'*Jcm6(4:6,:);

M=simplify(M)

%% Compute G
% Potential energie
P=m1*[0 0 g]*tcm1_0+...
  m2*[0 0 g]*tcm2_0+...
  m3*[0 0 g]*tcm3_0+...
  m4*[0 0 g]*tcm4_0+...
  m5*[0 0 g]*tcm5_0+...
  m6*[0 0 g]*tcm6_0;

G=[diff(P,q1);diff(P,q2);diff(P,q3);diff(P,q4);diff(P,q5);diff(P,q6)];
G=simplify(G)

%% Compute C
C=sym(zeros(6));
q=[q1;q2;q3;q4;q5;q6];
qp=[q1p;q2p;q3p;q4p;q5p;q6p];
qpp=[q1pp;q2pp;q3pp;q4pp;q5pp;q6pp];
qrp=[q1rp;q2rp;q3rp;q4rp;q5rp;q6rp];
qrpp=[q1rpp;q2rpp;q3rpp;q4rpp;q5rpp;q6rpp];

for k=1:6
    for j=1:6
        
            C(k,j)=0.5*qp'*[diff(M(k,j),q(1))+diff(M(k,1),q(j))-diff(M(1,j),q(k));
                            diff(M(k,j),q(2))+diff(M(k,2),q(j))-diff(M(2,j),q(k));
                            diff(M(k,j),q(3))+diff(M(k,3),q(j))-diff(M(3,j),q(k));
                            diff(M(k,j),q(4))+diff(M(k,4),q(j))-diff(M(4,j),q(k));
                            diff(M(k,j),q(5))+diff(M(k,5),q(j))-diff(M(5,j),q(k));
                            diff(M(k,j),q(6))+diff(M(k,6),q(j))-diff(M(6,j),q(k))];
            C(k,j)=expand(C(k,j));
            C(k,j)=simplify(C(k,j));
       
    end
end
C=simplify(C)
%% Verify if M-2C is skew symmetric.
N=[jacobian(M(:,1),q)*qp,jacobian(M(:,2),q)*qp,jacobian(M(:,3),q)*qp,jacobian(M(:,4),q)*qp,jacobian(M(:,5),q)*qp,jacobian(M(:,6),q)*qp]-2*C;
D2=simplify(expand(N+N'))
%% EoM
EoMr=M*qrpp+C*qrp+G;
EoMr=simplify(EoMr);
EoMr=subs(EoMr,{'d1' 'd2' 'd3' 'd4' 'd5' 'd6' 'dcm1' 'dcm2' 'dcm3' 'dcm4' 'dcm5' 'dcm6' 'a1' 'a2' 'a3' 'a4' 'a5' 'a6' 'acm1' 'acm2' 'acm3' 'acm4' 'acm5' 't1' 'm1' 'm2' 'm3' 'm4' 'm5' 'm6' 'g'},{0.1273 0 0 0.163941 0.1157 0.0922 0.1273 0.158 0.068 0.170941 0.1087 0.0662 0 -0.612 -0.5723 0 0 0 0.0342 -0.232 -0.3323 -0.018 -0.018 0.9098 7.1 12.7 4.27 2 2 0.365 9.81});
EoMr=subs(EoMr,{'I111' 'I112' 'I113' 'I122' 'I123' 'I133'},{0.04 0.02 0.02 0.04 0.02 0.04});
EoMr=subs(EoMr,{'I211' 'I212' 'I213' 'I222' 'I223' 'I233'},{0.04 0.02 0.02 0.04 0.02 0.04});
EoMr=subs(EoMr,{'I311' 'I312' 'I313' 'I322' 'I323' 'I333'},{0.04 0.02 0.02 0.04 0.02 0.04});
EoMr=subs(EoMr,{'I411' 'I412' 'I413' 'I422' 'I423' 'I433'},{0.04 0.02 0.02 0.04 0.02 0.04});
EoMr=subs(EoMr,{'I511' 'I512' 'I513' 'I522' 'I523' 'I533'},{0.04 0.02 0.02 0.04 0.02 0.04});
EoMr=subs(EoMr,{'I611' 'I612' 'I613' 'I622' 'I623' 'I633'},{0.04 0.02 0.02 0.04 0.02 0.04});

