function [Jef,X] = getJef_os_PD(u)

end

