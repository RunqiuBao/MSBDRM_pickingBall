function [opt1] = test(u)

opt1=[u(1),u(2),u(3)];
opt2=opt1;

end

