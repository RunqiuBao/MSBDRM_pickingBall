function [ Xout ] = SimpleRobotPlotROS( u )
%SIMPLEROBOTPLOT Summary of this function goes here
persistent  jointpub jointmsg counter tftree tfStampedMsg tfStampedMsg1 tfStampedMsg2 tfStampedMsg3
persistent  tfStampedMsgcm1 tfStampedMsgcm2 tfStampedMsgcm3 tfStampedMsgtar

%Joint Position
q1=u(1);
q2=u(2);
q3=u(3);

%Joint Velocity
qp1=u(4);
qp2=u(5);
qp3=u(6);

%Kinematic Parameters
L1=u(7);
L2=u(8);
L4=u(9);
L6=u(10);
L7=u(11);
L9=u(12);
L3=u(13);
L5=u(14);
L8=u(15);
L10=u(16);
L11=u(17);
L12=0.001*115.7;
L13=0;

%Time
t=u(40);

%target
x1=u(50);
x2=u(51);
x3=u(52);
x4=deg2rad(u(53));
x5=deg2rad(u(54));
x6=deg2rad(u(55));

% Specify the Robot Base (with respect to the world coordinate frame in ROS)
% T0_W=eye(4);
T0_W=[-1 0 0 0; 0 -1 0 0; 0 0 1 0; 0 0 0 1];

% Compute the Homogeneous Transformations

T1_0=[ cos(q1), 0,  sin(q1),  0;
       sin(q1), 0, -cos(q1),  0;
             0, 1,        0, L1;
             0, 0,        0,  1];
% T1_0=T1_0*[1 0 0 0;0 0 1 0;0 -1 0 0;0 0 0 1]*[0 1 0 0;-1 0 0 0;0 0 1 0;0 0 0 1]*[0 1 0 0;-1 0 0 0;0 0 1 0;0 0 0 1];

T2_1=[                  cos(q2),                        -sin(q2),        0,                                                  -L3*cos(q2);
                        sin(q2),                         cos(q2),        0,                                                  -L3*sin(q2);
                              0,                               0,        1,                                                           L7;
                              0,                               0,        0,                                                            1];

T3_2=[ cos(q3 + atan(L12/(L5 - L12))), -sin(q3 + atan(L12/(L5 - L12))),        0, -cos(q3 + atan(L12/(L5 - L12)))*(L12^2 + (L5 - L12)^2)^(1/2);
       sin(q3 + atan(L12/(L5 - L12))),  cos(q3 + atan(L12/(L5 - L12))),        0, -sin(q3 + atan(L12/(L5 - L12)))*(L12^2 + (L5 - L12)^2)^(1/2);
                                    0,                               0,        1,                                           L2 + L4 - L7 + L13;
                                    0,                               0,        0,                                                            1];

Tcm1_0=[ cos(q1), -sin(q1), 0,  0;
         sin(q1),  cos(q1), 0,  0;
               0,        0, 1, L6;
               0,        0, 0,  1];

Tcm2_1= [               cos(q2),                        -sin(q2),        0,                                                  -L8*cos(q2);
                        sin(q2),                         cos(q2),        0,                                                  -L8*sin(q2);
                              0,                               0,        1,                                                           L7;
                              0,                               0,        0,                                                            1];

Tcm3_2=[ cos(q3), -sin(q3), 0,   -L10*cos(q3);
         sin(q3),  cos(q3), 0,   -L10*sin(q3);
               0,        0, 1, -L7 + L9 + L11;
               0,        0, 0,             1];

% Stack of Transformations

T2_0=T1_0*T2_1;
T3_0=T2_0*T3_2;

Tcm2_0=T1_0*Tcm2_1;
Tcm3_0=T2_0*Tcm3_2;

T1_W=T0_W*T1_0;
T2_W=T0_W*T2_0;
T3_W=T0_W*T3_0;

Tcm1_W=T0_W*Tcm1_0;
Tcm2_W=T0_W*Tcm2_0;
Tcm3_W=T0_W*Tcm3_0;
%****************************************************
% Get the inverse Transformation(Transformation from
% header to child). (inverse mapping.)
TW_0=[T0_W(1:3,1:3)' -T0_W(1:3,1:3)'*T0_W(1:3,4);...
      0 0 0 1];
T0_1=[T1_0(1:3,1:3)' -T1_0(1:3,1:3)'*T1_0(1:3,4);...
      0 0 0 1];
T0_2=[T2_0(1:3,1:3)' -T2_0(1:3,1:3)'*T2_0(1:3,4);...
      0 0 0 1];  
T0_3=[T3_0(1:3,1:3)' -T3_0(1:3,1:3)'*T3_0(1:3,4);...
      0 0 0 1];    
T0_cm1=[Tcm1_0(1:3,1:3)' -Tcm1_0(1:3,1:3)'*Tcm1_0(1:3,4);...
        0 0 0 1];  
T0_cm2=[Tcm2_0(1:3,1:3)' -Tcm2_0(1:3,1:3)'*Tcm2_0(1:3,4);...
        0 0 0 1];      
T0_cm3=[Tcm3_0(1:3,1:3)' -Tcm3_0(1:3,1:3)'*Tcm3_0(1:3,4);...
        0 0 0 1];      
    
Rt_0=[cos(x6),-sin(x6),0;
    sin(x6),cos(x6),0;
    0 0 1]*[cos(x5),0,sin(x5);
            0 1 0;
            -sin(x5),0,cos(x5)]*[1,0,0;0,cos(x4),-sin(x4);0,sin(x4),cos(x4)];
Rt_w=T0_W(1:3,1:3)*Rt_0;
tt_w=[x1;x2;x3];
T_target=[Rt_w,tt_w;0 0 0 1];
%****************************************************
% Get the position of the end-effector
Xef_W=[T3_W(1:3,4);R2EulerA(T3_W(1:3,1:3))];

%% Initialize the publishers and messages
if t<0.05 %depend on the fixed step size
    % TF publisher
    tftree = rostf;
    tfStampedMsg = rosmessage('geometry_msgs/TransformStamped');
    tfStampedMsg1 = rosmessage('geometry_msgs/TransformStamped');
    tfStampedMsg2 = rosmessage('geometry_msgs/TransformStamped');
    tfStampedMsg3 = rosmessage('geometry_msgs/TransformStamped');
    tfStampedMsgcm1 = rosmessage('geometry_msgs/TransformStamped');
    tfStampedMsgcm2 = rosmessage('geometry_msgs/TransformStamped');
    tfStampedMsgcm3 = rosmessage('geometry_msgs/TransformStamped');
    tfStampedMsgtar = rosmessage('geometry_msgs/TransformStamped');
    
    % Build the tf tree
    % H0_W
    tfStampedMsg.ChildFrameId = 'TF0';
    tfStampedMsg.Header.FrameId = 'world';
    
    % H1_0
    tfStampedMsg1.ChildFrameId = 'TF1';
    tfStampedMsg1.Header.FrameId ='TF0';
    
    % H2_0
    tfStampedMsg2.ChildFrameId = 'TF2';
    tfStampedMsg2.Header.FrameId = 'TF0';
    
    % H3_0
    tfStampedMsg3.ChildFrameId = 'TF3';
    tfStampedMsg3.Header.FrameId = 'TF0';
    
    %Hcm1_0
    tfStampedMsgcm1.ChildFrameId = 'TFcm1';
    tfStampedMsgcm1.Header.FrameId ='TF0';
    
    %Hcm2_0
    tfStampedMsgcm2.ChildFrameId = 'TFcm2';
    tfStampedMsgcm2.Header.FrameId = 'TF0';
    
    %Hcm3_0
    tfStampedMsgcm3.ChildFrameId = 'TFcm3';
    tfStampedMsgcm3.Header.FrameId = 'TF0';  
    
    %target
    tfStampedMsgtar.ChildFrameId = 'TFtarget';
    tfStampedMsgtar.Header.FrameId = 'TF0';
    
    % Joint State Publisher
    jointpub = rospublisher('/ursa_joint_states','sensor_msgs/JointState');
    jointmsg = rosmessage(jointpub); 
    
    % Specific names of the joints
    jointmsg.Name = {'ursa_shoulder_pan_joint',...
                     'ursa_shoulder_lift_joint',...
                     'ursa_elbow_joint',...
                     'ursa_wrist_1_joint',...
                     'ursa_wrist_2_joint',...
                     'ursa_wrist_3_joint'};
    for i=1:6
        jointmsg.Velocity(i)=0;
        jointmsg.Effort(i)=0;
    end
    
    counter=0;
end


%Publish the robot joints and tf's (Base, Links, CMs and EF), see the joint names generated by bringUR10.launch
%% JOINT STATE MSG
    jointmsg.Header.Stamp=tfStampedMsg.Header.Stamp;
    jointmsg.Header.Seq=counter;
    counter=counter+1;
    
    jointmsg.Position=[q1,q2,q3];
    send(jointpub,jointmsg);
    
%% TF MSG
    tfStampedMsg.Header.Stamp = rostime('now');
    tfStampedMsg.Header.Seq=counter;
    tfStampedMsg.Transform.Translation.X = T0_W(1,4);
    tfStampedMsg.Transform.Translation.Y = T0_W(2,4);
    tfStampedMsg.Transform.Translation.Z = T0_W(3,4);

     rotm = T0_W(1:3,1:3);
     quatrot = rotm2quat(rotm);
     tfStampedMsg.Transform.Rotation.W = quatrot(1);
     tfStampedMsg.Transform.Rotation.X = quatrot(2);
     tfStampedMsg.Transform.Rotation.Y = quatrot(3);
     tfStampedMsg.Transform.Rotation.Z = quatrot(4);
    sendTransform(tftree, tfStampedMsg);
    %************************************************************
    tfStampedMsg1.Header.Stamp = rostime('now');
    tfStampedMsg1.Header.Seq=counter;
    tfStampedMsg1.Transform.Translation.X = T1_0(1,4);
    tfStampedMsg1.Transform.Translation.Y = T1_0(2,4);
    tfStampedMsg1.Transform.Translation.Z = T1_0(3,4);

    rotm = T1_0(1:3,1:3);
    quatrot = rotm2quat(rotm);
    tfStampedMsg1.Transform.Rotation.W = quatrot(1);
    tfStampedMsg1.Transform.Rotation.X = quatrot(2);
    tfStampedMsg1.Transform.Rotation.Y = quatrot(3);
    tfStampedMsg1.Transform.Rotation.Z = quatrot(4);
    sendTransform(tftree, tfStampedMsg1);
    %************************************************************
    tfStampedMsg2.Header.Stamp = rostime('now');
    tfStampedMsg2.Header.Seq=counter;
    tfStampedMsg2.Transform.Translation.X = T2_0(1,4);
    tfStampedMsg2.Transform.Translation.Y = T2_0(2,4);
    tfStampedMsg2.Transform.Translation.Z = T2_0(3,4);

    rotm = T2_0(1:3,1:3);
    quatrot = rotm2quat(rotm);
    tfStampedMsg2.Transform.Rotation.W = quatrot(1);
    tfStampedMsg2.Transform.Rotation.X = quatrot(2);
    tfStampedMsg2.Transform.Rotation.Y = quatrot(3);
    tfStampedMsg2.Transform.Rotation.Z = quatrot(4);
    sendTransform(tftree, tfStampedMsg2);
    %************************************************************
    
    tfStampedMsg3.Header.Stamp = rostime('now');
    tfStampedMsg3.Header.Seq=counter;
    tfStampedMsg3.Transform.Translation.X = T3_0(1,4);
    tfStampedMsg3.Transform.Translation.Y = T3_0(2,4);
    tfStampedMsg3.Transform.Translation.Z = T3_0(3,4);

    rotm = T3_0(1:3,1:3);
    quatrot = rotm2quat(rotm);
    tfStampedMsg3.Transform.Rotation.W = quatrot(1);
    tfStampedMsg3.Transform.Rotation.X = quatrot(2);
    tfStampedMsg3.Transform.Rotation.Y = quatrot(3);
    tfStampedMsg3.Transform.Rotation.Z = quatrot(4);
    sendTransform(tftree, tfStampedMsg3);
    %************************************************************
       
    tfStampedMsgcm1.Header.Stamp = rostime('now');
    tfStampedMsgcm1.Header.Seq=counter;
    tfStampedMsgcm1.Transform.Translation.X = Tcm1_0(1,4);
    tfStampedMsgcm1.Transform.Translation.Y = Tcm1_0(2,4);
    tfStampedMsgcm1.Transform.Translation.Z = Tcm1_0(3,4);

    rotm = Tcm1_0(1:3,1:3);
    quatrot = rotm2quat(rotm);
    tfStampedMsgcm1.Transform.Rotation.W = quatrot(1);
    tfStampedMsgcm1.Transform.Rotation.X = quatrot(2);
    tfStampedMsgcm1.Transform.Rotation.Y = quatrot(3);
    tfStampedMsgcm1.Transform.Rotation.Z = quatrot(4);
    sendTransform(tftree, tfStampedMsgcm1);
    %************************************************************
    
    tfStampedMsgcm2.Header.Stamp = rostime('now');
    tfStampedMsgcm2.Header.Seq=counter;
    tfStampedMsgcm2.Transform.Translation.X = Tcm2_0(1,4);
    tfStampedMsgcm2.Transform.Translation.Y = Tcm2_0(2,4);
    tfStampedMsgcm2.Transform.Translation.Z = Tcm2_0(3,4);

    rotm = Tcm2_0(1:3,1:3);
    quatrot = rotm2quat(rotm);
    tfStampedMsgcm2.Transform.Rotation.W = quatrot(1);
    tfStampedMsgcm2.Transform.Rotation.X = quatrot(2);
    tfStampedMsgcm2.Transform.Rotation.Y = quatrot(3);
    tfStampedMsgcm2.Transform.Rotation.Z = quatrot(4);
    sendTransform(tftree, tfStampedMsgcm2);
    %************************************************************
    
    tfStampedMsgcm3.Header.Stamp = rostime('now');
    tfStampedMsgcm3.Header.Seq=counter;
    tfStampedMsgcm3.Transform.Translation.X = Tcm3_0(1,4);
    tfStampedMsgcm3.Transform.Translation.Y = Tcm3_0(2,4);
    tfStampedMsgcm3.Transform.Translation.Z = Tcm3_0(3,4);

    rotm = Tcm3_0(1:3,1:3);
    quatrot = rotm2quat(rotm);
    tfStampedMsgcm3.Transform.Rotation.W = quatrot(1);
    tfStampedMsgcm3.Transform.Rotation.X = quatrot(2);
    tfStampedMsgcm3.Transform.Rotation.Y = quatrot(3);
    tfStampedMsgcm3.Transform.Rotation.Z = quatrot(4);
    sendTransform(tftree, tfStampedMsgcm3);
    %************************************************************ 
    tfStampedMsgtar.Header.Stamp = rostime('now');
    tfStampedMsgtar.Header.Seq=counter;
    tfStampedMsgtar.Transform.Translation.X = double(T_target(1,4));
    tfStampedMsgtar.Transform.Translation.Y = double(T_target(2,4));
    tfStampedMsgtar.Transform.Translation.Z = double(T_target(3,4));

    rotm = T_target(1:3,1:3);
    quatrot = rotm2quat(rotm);%四元数表示一个旋转，
    tfStampedMsgtar.Transform.Rotation.W = quatrot(1);
    tfStampedMsgtar.Transform.Rotation.X = quatrot(2);
    tfStampedMsgtar.Transform.Rotation.Y = quatrot(3);
    tfStampedMsgtar.Transform.Rotation.Z = quatrot(4);
    sendTransform(tftree, tfStampedMsgtar);
    %************************************************************  
    %Use the above example to plot the TF of each joint and each center 
    %of mass using the Homogenous transformations obtained from 
    %D-H parameters. You will need the joint positions which are generated
    %with the JOINT STATE MSG publisher (see above)
%%
Xout=Xef_W(1:3);
end