%function [HT_symbolic]=DH2HT(D_symbolic)
% This is relative HT
HT_symbolic(1:4,:)=simplify([RotZ(D_symbolic(1,1)) [0 0 D_symbolic(1,2)]'; 0 0 0 1]* ...
                           [RotX(D_symbolic(1,4)) [D_symbolic(1,3) 0 0]'; 0 0 0 1]);
      
HT_symbolic(5:8,:)=simplify([RotZ(D_symbolic(2,1)) [0 0 D_symbolic(2,2)]'; 0 0 0 1]* ...
                            [RotX(D_symbolic(2,4)) [D_symbolic(2,3) 0 0]'; 0 0 0 1]);
      
HT_symbolic(9:12,:)=simplify([RotZ(D_symbolic(3,1)) [0 0 D_symbolic(3,2)]'; 0 0 0 1]* ...
                            [RotX(D_symbolic(3,4)) [D_symbolic(3,3) 0 0]'; 0 0 0 1]);

% Center of Mass                        
HT_symbolic(13:16,:)=simplify([RotZ(D_symbolic(4,1)) [0 0 D_symbolic(4,2)]'; 0 0 0 1]* ...
                            [RotX(D_symbolic(4,4)) [D_symbolic(4,3) 0 0]'; 0 0 0 1]);                        
      
HT_symbolic(17:20,:)=simplify([RotZ(D_symbolic(5,1)) [0 0 D_symbolic(5,2)]'; 0 0 0 1]* ...
                            [RotX(D_symbolic(5,4)) [D_symbolic(5,3) 0 0]'; 0 0 0 1]);  
                        
HT_symbolic(21:24,:)=simplify([RotZ(D_symbolic(6,1)) [0 0 D_symbolic(6,2)]'; 0 0 0 1]* ...
                            [RotX(D_symbolic(6,4)) [D_symbolic(6,3) 0 0]'; 0 0 0 1]);  
                        
%end