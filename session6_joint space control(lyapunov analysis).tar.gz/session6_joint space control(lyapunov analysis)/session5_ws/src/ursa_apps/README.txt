#To use this ros package you need to install ros-kinetic-universal-robot. 
#This ros package provides ur_description marked as dependency.
#see: http://wiki.ros.org/universal_robot

#For tutorial 5 you need to run
roslaunch ursa_apps bringUR10.launch