function [qd] = TrajGen( u )
%TRAJGEN Summary of this function goes here
%   Detailed explanation goes here

%global t0 t1 t2 t3 t4 t5 t6

t=u(4);
tf=1;%moving time
%initial state of the joints
q1_0=0;
q2_0=0;%deg2rad(90);
q3_0=0;
% Interval between PD, PD+G, and PID+G
% Generate Different trajectories at different times
q1d=u(1);
q2d=u(2);
q3d=u(3);

%produce traj time function
%6th order polynomial
% a1=[1 0 0 0 0 0;
%    1 tf tf^2 tf^3 tf^4 tf^5;
%    0 1 0 0 0 0;
%    0 1 2*tf 3*tf^2 4*tf^3 5*tf^4;
%    0 0 2 0 0 0;
%    0 0 2 6*tf 12*tf^2 20*tf^3]^(-1)*[q1_0;q1d;0;0;0;0];%coefficient matrix
% a2=[1 0 0 0 0 0;
%    1 tf tf^2 tf^3 tf^4 tf^5;
%    0 1 0 0 0 0;
%    0 1 2*tf 3*tf^2 4*tf^3 5*tf^4;
%    0 0 2 0 0 0;
%    0 0 2 6*tf 12*tf^2 20*tf^3]^(-1)*[q2_0;q2d;0;0;0;0];%coefficient matrix
% a3=[1 0 0 0 0 0;
%    1 tf tf^2 tf^3 tf^4 tf^5;
%    0 1 0 0 0 0;
%    0 1 2*tf 3*tf^2 4*tf^3 5*tf^4;
%    0 0 2 0 0 0;
%    0 0 2 6*tf 12*tf^2 20*tf^3]^(-1)*[q3_0;q3d;0;0;0;0];%coefficient matrix
% t_poly=[1;t;t^2;t^3;t^4;t^5];%time polynomial

%sigmoid function
% q1d_next=1/(1+exp(-8*(t+8)/tf))+q1d-1;
% q2d_next=1/(1+exp(-8*(t+8)/tf))+q2d-1;
% q3d_next=1/(1+exp(-8*(t+8)/tf))+q3d-1;
% q1d_next=a1'*t_poly;
% q2d_next=a2'*t_poly;
% q3d_next=a3'*t_poly;

%qd=[a1'*t_poly;a2'*t_poly;a3'*t_poly];
% qd=[q1d_next;q2d_next;q3d_next];
% qd=double(qd);

%starting value
% if(t<0.005)
%     qd=[0.0000001;0.0000001;0.0000001];
qd=[q1d;q2d;q3d];

end

