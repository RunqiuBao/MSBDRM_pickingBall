function [M,C,G] = getEoM(I1,I2,I3)

%syms g z0 m1 m2 m3  l1 l2 l3 l4 l5 l6 l7 l8 l9 l10 l11 l12 l13 q1 q2 q3 q1p q2p q3p real 
syms g z0 m1 m2 m3  L1 L2 L3 L4 L5 L6 L7 L8 L9 L10 L11 L12 L13 q1 q2 q3 q1p q2p q3p real 
Jcm1=[0 0 0;0 0 0;0 0 0;0 0 0;0 0 0;1 0 0];
Jcm2=[L7*cos(q1) + L8*sin(q1)*sin(q2), -L8*cos(q1)*cos(q2), 0;
    L7*sin(q1) - L8*cos(q1)*sin(q2), -L8*cos(q2)*sin(q1), 0;
    0,-L8*sin(q2), 0;
    0,sin(q1),0;
    0,-cos(q1), 0;
    1,0, 0];
Jcm3=[L9*cos(q1) + L11*cos(q1) + L3*sin(q1)*sin(q2) - L10*cos(q2)*sin(q1)*sin(q3) + L10*cos(q3)*sin(q1)*sin(q2),-cos(q1)*(L3*cos(q2) + L10*cos(q2 - q3)),L10*cos(q2 - q3)*cos(q1);
    L9*sin(q1) + L11*sin(q1) - L3*cos(q1)*sin(q2) + L10*cos(q1)*cos(q2)*sin(q3) - L10*cos(q1)*cos(q3)*sin(q2),-sin(q1)*(L3*cos(q2) + L10*cos(q2 - q3)),L10*cos(q2 - q3)*sin(q1);
    0, - L3*sin(q2) - L10*sin(q2 - q3),L10*sin(q2 - q3);
    0,sin(q1),-sin(q1);
    0,-cos(q1),cos(q1);
    1,0,0];

Rcm1_0=[cos(q1), -sin(q1), 0;sin(q1),  cos(q1), 0;0 0 1];
Rcm2_0=[cos(q1)*sin(q2), cos(q1)*cos(q2),  sin(q1);
        sin(q1)*sin(q2), cos(q2)*sin(q1), -cos(q1);
        -cos(q2),         sin(q2),        0];
Rcm3_0=[sin(q2 - q3)*cos(q1), -cos(q2 - q3)*cos(q1), -sin(q1);
        sin(q2 - q3)*sin(q1), -cos(q2 - q3)*sin(q1),  cos(q1);
        -cos(q2 - q3),         -sin(q2 - q3),        0];

M=m1*Jcm1(1:3,1:3)'*Jcm1(1:3,1:3)+m2*Jcm2(1:3,1:3)'*Jcm2(1:3,1:3)+m3*Jcm3(1:3,1:3)'*Jcm3(1:3,1:3);
M=M+Jcm1(4:6,4:6)'*Rcm1_0*I1*Rcm1_0'*Jcm1(4:6,4:6)+Jcm2(4:6,4:6)'*Rcm2_0*I2*Rcm2_0'*Jcm2(4:6,4:6)+Jcm3(4:6,4:6)'*Rcm3_0*I3*Rcm3_0'*Jcm3(4:6,4:6);
C=zeros(3);
C=sym(C);
q=[q1 q2 q3];
qp=[q1p q2p q3p];
for k=1:3
  for j=1:3
    for i=1:3
      C(k,j)=C(k,j)+0.5*qp(i)*(diff(M(k,j),q(i))+diff(M(k,i),q(j))-diff(M(i,j),q(k)));
    end
  end
end
P=m1*g*(-q1-z0)+0.5*k1*(q1-z0)^2+m2*g*(-z0-q1-l2*cos(q2))+0.5*k2*(q2-th1)^2+m3*g*(-z0-q1-l2*cos(q2)-l3*cos(q2+q3))+0.5*k3*(q3-th2)^2;
G=[0 0 0];
G=sym(G);
G(1)=diff(P,q1);G(2)=diff(P,q2);G(3)=diff(P,q3);

end

