function [ tau ] = Tau( u )
%TAU Summary of this function goes here
%   Detailed explanation goes here
% Times are defined in TrajGen.m file
global t0 t1 t2 t3 t4 t5 t6

t=u(1);

q1d=deg2rad(u(2));
q2d=deg2rad(u(3));
q3d=deg2rad(u(4));

q1dp=deg2rad(u(5));
q2dp=deg2rad(u(6));
q3dp=deg2rad(u(7));

Kd=diag([u(8);u(9);u(10)]);
Kp=diag([u(11);u(12);u(13)]);

q1=u(14);
q2=u(15);
q3=u(16);

q1p=u(17);
q2p=u(18);
q3p=u(19);

Q=[q1;q2;q3];
Qp=[q1p;q2p;q3p];

Qd=[q1d;q2d;q3d];
Qdp=[q1dp;q2dp;q3dp];

%Joint Errors


%Robot Parameters

m1=u(20);
m2=u(21);
m3=u(22);
g=u(23);

L1=u(24);
L2=u(25);
L4=u(26);
L6=u(27);
L7=u(28);
L9=u(29);
L3=u(30);
L5=u(31);
L8=u(32);
L10=u(33);







Kis=diag([u(37);u(38);u(39)]);
Ki=diag([0;0;0]);




gx=u(41);
gy=u(42);
gz=u(43);



if (t>=t1)
    %Compute G
end


%Define controllers PD, PD+G, PID
tauc



tau=[tauc;DeltaQ;DeltaQp];

end

